<?php
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/mailer.php';
require_once __DIR__ . '/table_pdf_helper.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = trim((string)($_GET['action'] ?? ''));
$id = trim((string)($_GET['id'] ?? ''));
$payload = current_token_payload();
if (!$payload) json_error('Not authenticated', 401);

const BREAKDOWN_STAGE_META = [
    'WORKSHOP_REVIEW' => ['department' => 'Workshop', 'slaHours' => 4],
    'TECHNICIAN_ASSIGNMENT' => ['department' => 'Workshop / Dispatch', 'slaHours' => 4],
    'JOB_CARD_ASSIGNED' => ['department' => 'Technician', 'slaHours' => 4],
    'DIAGNOSIS' => ['department' => 'Technician', 'slaHours' => 8],
    'BOSS_APPROVAL' => ['department' => 'Administration Approval', 'slaHours' => 4],
    'STORE_CHECK' => ['department' => 'Store Keeper', 'slaHours' => 6],
    'PROCUREMENT' => ['department' => 'Procurement', 'slaHours' => 24],
    'ACCOUNTS' => ['department' => 'Accounts', 'slaHours' => 8],
    'PARTS_READY' => ['department' => 'Workshop', 'slaHours' => 4],
    'REPAIR' => ['department' => 'Technician', 'slaHours' => 24],
    'TESTING' => ['department' => 'Workshop', 'slaHours' => 8],
    'PENDING_APPROVAL' => ['department' => 'Administration / Technical Dep', 'slaHours' => 8],
    'COMPLETED' => ['department' => 'Completed', 'slaHours' => 0],
];

function bw_context(array $payload): array {
    if (($payload['type'] ?? '') === 'customer') {
        $customer = require_customer_auth();
        $permissions = $customer['permissions'] ?? null;
        $isOwner = ($customer['actorType'] ?? '') === 'owner';
        $role = strtolower(trim((string)($customer['customerRole'] ?? ($isOwner ? 'owner' : ''))));
        $allowed = $isOwner || (is_array($permissions) && in_array('workflow', $permissions, true));
        if (!$allowed) json_error('Your Role Manager access does not include Breakdown Workflow.', 403);
        return [
            'kind' => 'customer', 'customerId' => (string)$customer['id'], 'isOwner' => $isOwner,
            'role' => $role, 'actorId' => (string)($customer['actorId'] ?? $customer['id']),
            'actorName' => (string)($customer['actorName'] ?? $customer['name'] ?? 'Customer User'),
            'canOverrideTechnician' => false,
            'canApproveJob' => $isOwner || in_array($role, ['admin','workshop_manager'], true),
        ];
    }
    $user = require_auth();
    $isTech = ($user['roleName'] ?? '') === 'Technician';
    $isCustomerManaged = false;
    if ($isTech && !empty($user['id'])) {
        $ownership = db()->prepare('SELECT is_customer_managed FROM users WHERE id = ? AND deleted_at IS NULL');
        $ownership->execute([(string)$user['id']]);
        $isCustomerManaged = !empty($ownership->fetchColumn());
    }
    if (!$isTech) require_any_page_access($user, ['job-cards','service-requests']);
    return [
        'kind' => $isCustomerManaged ? 'customer-tech' : 'belm',
        'customerId' => (string)($user['assignedCustomerId'] ?? ''),
        'isOwner' => false, 'role' => strtolower((string)($user['roleName'] ?? 'staff')),
        'actorId' => (string)($user['id'] ?? ''), 'actorName' => (string)($user['name'] ?? 'BELM'),
        'isTechnician' => $isTech, 'isCustomerManaged' => $isCustomerManaged,
        'canOverrideTechnician' => !$isTech && belm_can_override_technician_customer($user),
        'canApproveJob' => !$isTech && belm_user_has_named_role($user, ['Super Admin','Engineer','Workshop Manager']),
    ];
}

function bw_case_access(array $ctx, string $caseId): array {
    $stmt = db()->prepare(
        'SELECT bc.*, c.name AS customer_name, c.address AS customer_address, c.is_machinery_admin,
                m.brand, m.model, m.machine_type, m.serial_number, m.reg_number, m.fleet_number
         FROM breakdown_cases bc
         JOIN customers c ON c.id = bc.customer_id
         JOIN machines m ON m.id = bc.machine_id
         WHERE bc.id = ? AND c.deleted_at IS NULL AND m.deleted_at IS NULL'
    );
    $stmt->execute([$caseId]);
    $case = $stmt->fetch();
    if (!$case) json_error('Breakdown case not found.', 404);
    if ($ctx['kind'] === 'customer') {
        if ((string)$case['customer_id'] !== $ctx['customerId']) json_error('Not allowed.', 403);
    } elseif ($ctx['kind'] === 'customer-tech') {
        if ((string)$case['customer_id'] !== $ctx['customerId']) json_error('This machine is not assigned to this Technician.', 403);
        // When BELM provider mode is ON, customer Technicians do not gain broad fleet
        // access. They may still work an internal Job Card explicitly assigned to them
        // by their Customer Admin / Workshop Manager.
        if (empty($case['is_machinery_admin'])) {
            $assigned = db()->prepare("SELECT 1 FROM digital_job_cards WHERE case_id=? AND technician_id=? AND status NOT IN ('COMPLETED','CANCELLED') LIMIT 1");
            $assigned->execute([$caseId, $ctx['actorId']]);
            if (!$assigned->fetchColumn()) json_error('Customer Technician access is limited to Job Cards assigned to you while BELM Service Provider is active.', 403);
        }
    } else {
        $officialSupport = (($case['source_type'] ?? '') === 'SERVICE_REQUEST');
        // Provider-OFF customers remain private to their own workshop, except
        // for an official BELM Support Request that deliberately invites BELM.
        if (!empty($case['is_machinery_admin']) && !$officialSupport) {
            json_error('This customer is using its own maintenance team.', 403);
        }
        if (!empty($ctx['isTechnician'])) {
            $jobAccess = db()->prepare('SELECT 1 FROM digital_job_cards WHERE case_id=? AND technician_id=? LIMIT 1');
            $jobAccess->execute([$caseId, $ctx['actorId']]);
            $hasJob = (bool)$jobAccess->fetchColumn();
            $requestAssigned = false;
            if ($officialSupport && !empty($case['source_id'])) {
                $sr = db()->prepare('SELECT 1 FROM service_requests WHERE id=? AND assigned_to_id=? LIMIT 1');
                $sr->execute([(string)$case['source_id'], $ctx['actorId']]);
                $requestAssigned = (bool)$sr->fetchColumn();
            }
            if (!empty($case['is_machinery_admin'])) {
                if (!$hasJob && !$requestAssigned) json_error('This BELM Support Request is not assigned to this Technician.', 403);
            } elseif ($ctx['customerId'] !== '' && $ctx['customerId'] !== (string)$case['customer_id'] && !$hasJob) {
                json_error('This machine is not assigned to this Technician and no Temporary Override exists for this Job Card.', 403);
            }
        }
    }
    return $case;
}

function bw_is_technician_actor(array $ctx): bool {
    return !empty($ctx['isTechnician'])
        || $ctx['kind'] === 'customer-tech'
        || ($ctx['kind'] === 'customer' && strtolower((string)($ctx['role'] ?? '')) === 'technician');
}

// V763: translate Maintenance Process movement into the shared Role Communication
// inbox. This is best-effort only; the Job Card/Spare write remains authoritative.
function bw_role_key(array $ctx): string {
    if (($ctx['kind'] ?? '') === 'belm') {
        $role = strtolower(trim((string)($ctx['role'] ?? '')));
        return match ($role) {
            'super admin' => 'super_admin',
            'workshop manager', 'engineer' => 'workshop_manager',
            'technician' => 'technician',
            'procurement' => 'procurement',
            'store keeper' => 'store_keeper',
            'registration & sales' => 'registration_sales',
            'finance / accounts' => 'finance_accounts',
            'bank controller' => 'bank_controller',
            'system coordinator' => 'system_coordinator',
            default => preg_replace('/[^a-z0-9]+/', '_', $role) ?: 'staff',
        };
    }
    if (($ctx['kind'] ?? '') === 'customer-tech') return 'technician';
    $role = strtolower(trim((string)($ctx['role'] ?? '')));
    return match ($role) {
        'owner', 'admin', 'customer_admin' => 'customer_admin',
        'workshop manager', 'workshop_manager' => 'workshop_manager',
        'store keeper', 'store_keeper' => 'store_keeper',
        'finance', 'accounts', 'accountant' => 'accounts',
        default => preg_replace('/[^a-z0-9]+/', '_', $role) ?: 'customer_admin',
    };
}

function bw_role_message(array $ctx, array $case, string $recipientScope, string $recipientRole, string $subject, string $message, string $priority='NORMAL', ?string $relatedType=null, ?string $relatedId=null): void {
    $senderScope = ($ctx['kind'] ?? '') === 'belm' ? 'BELM' : 'CUSTOMER';
    $actorId = trim((string)($ctx['actorId'] ?? ''));
    $actorKey = strtolower($senderScope) . '-workflow:' . ($actorId !== '' ? $actorId : 'system');
    $actor = $recipientScope === 'BELM' ? 'admin' : 'customer';
    $caseId = trim((string)($case['id'] ?? $case['case_id'] ?? ''));
    $url = '/breakdown-workflow/?actor=' . $actor . ($caseId !== '' ? '&case=' . rawurlencode($caseId) : '');
    belm_role_communication_insert(
        trim((string)($case['customer_id'] ?? '')) ?: null,
        $senderScope, $actorKey, (string)($ctx['actorName'] ?? 'Portal User'), bw_role_key($ctx),
        strtoupper($recipientScope), $recipientRole, $subject, $message, $priority,
        $relatedType, $relatedId, trim((string)($case['machine_id'] ?? '')) ?: null, $url
    );
}

function bw_require_assigned_job(array $ctx, array $job): void {
    if (!bw_is_technician_actor($ctx)) return;
    $actorId = trim((string)($ctx['actorId'] ?? ''));
    $jobTechId = trim((string)($job['technician_id'] ?? ''));
    if ($actorId !== '' && $jobTechId === $actorId) return;

    // V342: legacy/interrupted Job Card sync can leave the source request
    // assigned to the Technician while digital_job_cards.technician_id is still
    // NULL. Recover only that safe missing-assignment case; never override a Job
    // Card that is explicitly assigned to a different Technician.
    if ($actorId !== '' && $jobTechId === '' && !empty($job['id'])) {
        $recover = db()->prepare(
            "SELECT sr.assigned_to_id,u.name AS assigned_to_name
             FROM digital_job_cards j
             JOIN breakdown_cases bc ON bc.id=j.case_id
             JOIN service_requests sr ON bc.source_type='SERVICE_REQUEST' AND sr.id=bc.source_id
             LEFT JOIN users u ON u.id=sr.assigned_to_id
             WHERE j.id=? LIMIT 1"
        );
        $recover->execute([(string)$job['id']]);
        $sourceAssignment = $recover->fetch() ?: [];
        if (trim((string)($sourceAssignment['assigned_to_id'] ?? '')) === $actorId) {
            $name = trim((string)($sourceAssignment['assigned_to_name'] ?? '')) ?: (string)($ctx['actorName'] ?? 'Technician');
            db()->prepare(
                "UPDATE digital_job_cards
                 SET technician_id=?,technician_name=?,
                     status=CASE WHEN UPPER(COALESCE(status,'')) IN ('OPEN','RECEIVED') THEN 'ASSIGNED' ELSE status END,
                     updated_at=NOW()
                 WHERE id=? AND technician_id IS NULL"
            )->execute([$actorId,$name,(string)$job['id']]);
            return;
        }
    }
    json_error('This Job Card is not assigned to this Technician.', 403);
}

function bw_log(string $caseId, string $stage, string $department, string $action, ?string $note, array $ctx): void {
    db()->prepare(
        'INSERT INTO breakdown_case_events
         (id, case_id, stage, department, action, note, actor_type, actor_id, actor_name, created_at)
         VALUES (?,?,?,?,?,?,?,?,?,NOW())'
    )->execute([uuid(), $caseId, $stage, $department, $action, $note, $ctx['kind'], $ctx['actorId'] ?: null, $ctx['actorName'],]);
}

function bw_set_stage(string $caseId, string $stage, ?string $blocker, array $ctx, string $action = 'Stage updated'): void {
    $meta = BREAKDOWN_STAGE_META[$stage] ?? null;
    if (!$meta) json_error('Invalid workflow stage.');
    $closed = $stage === 'COMPLETED';
    db()->prepare(
        'UPDATE breakdown_cases SET current_stage=?, current_department=?, blocker_reason=?, stage_started_at=NOW(),
         status=?, updated_at=NOW(), closed_at=CASE WHEN ? THEN NOW() ELSE NULL END WHERE id=?'
    )->execute([$stage, $meta['department'], $blocker ?: null, $closed ? 'COMPLETED' : 'OPEN', $closed ? 1 : 0, $caseId]);
    bw_log($caseId, $stage, $meta['department'], $action, $blocker, $ctx);
    // V220: closing a synced Breakdown Case closes its official source too.
    if ($closed) {
        try {
            $srcStmt = db()->prepare('SELECT source_type,source_id FROM breakdown_cases WHERE id=?');
            $srcStmt->execute([$caseId]);
            $src = $srcStmt->fetch();
            if ($src && ($src['source_type'] ?? '') === 'SERVICE_REQUEST' && !empty($src['source_id'])) {
                $sr = db()->prepare("SELECT status FROM service_requests WHERE id=?");
                $sr->execute([(string)$src['source_id']]);
                $previous = $sr->fetchColumn();
                if ($previous && !in_array((string)$previous,['COMPLETED','CANCELLED'],true)) {
                    db()->prepare("UPDATE service_requests SET status='COMPLETED',completed_at=COALESCE(completed_at,NOW()),updated_at=NOW() WHERE id=?")->execute([(string)$src['source_id']]);
                    $serviceActorId = $ctx['kind']==='belm' ? ($ctx['actorId'] ?: null) : null;
                    db()->prepare('INSERT INTO service_request_history(id,request_id,event_type,from_value,to_value,actor_id,actor_name,note,created_at) VALUES(?,?,?,?,?,?,?,?,NOW())')
                        ->execute([uuid(),(string)$src['source_id'],'STATUS',(string)$previous,'COMPLETED',$serviceActorId,$ctx['actorName'],'Completed from Breakdown Process']);
                }
            } elseif ($src && ($src['source_type'] ?? '') === 'OPERATOR_REPORT' && !empty($src['source_id'])) {
                db()->prepare("UPDATE operator_reports SET status='RESOLVED',resolved_at=COALESCE(resolved_at,NOW()) WHERE id=? AND status='OPEN'")->execute([(string)$src['source_id']]);
            }
        } catch (Throwable $syncError) {
            error_log('Breakdown source close sync failed: ' . $syncError->getMessage());
        }
    }
}

function bw_ensure_case_from_report(string $reportId, array $ctx): ?string {
    $caseId = belm_ensure_breakdown_case_from_operator_report($reportId, (string)($ctx['actorName'] ?? 'Operator'), true);
    if ($caseId) belm_ensure_job_card_for_breakdown_case($caseId, (string)($ctx['actorName'] ?? 'System'), true);
    return $caseId;
}

function bw_signed_copy_upload(string $dataUrl, string $name): array {
    $dataUrl = trim($dataUrl);
    if (!preg_match('#^data:(application/pdf|image/jpeg|image/png|image/webp);base64,(.+)$#s', $dataUrl, $m)) {
        json_error('Signed Job Card must be a PDF, JPG, PNG or WebP file.', 422);
    }
    $binary = base64_decode($m[2], true);
    if ($binary === false) json_error('Signed Job Card file is damaged.', 422);
    if (strlen($binary) > 5 * 1024 * 1024) json_error('Signed Job Card is too large (max 5MB).', 422);
    $safeName = preg_replace('/[^A-Za-z0-9._-]+/', '-', trim($name)) ?: 'signed-job-card';
    return [base64_encode($binary), $m[1], $safeName];
}

function bw_reported_context(array $row): array {
    $reportedAt = $row['opened_at'] ?? null;
    $machineHours = null;
    $sourceType = strtoupper(trim((string)($row['source_type'] ?? 'BREAKDOWN_CASE')));
    $sourceId = trim((string)($row['source_id'] ?? ''));
    try {
        if ($sourceType === 'CHECKLIST_REPORT' && $sourceId !== '') {
            $q = db()->prepare('SELECT created_at,hour_meter_reading FROM checklist_reports WHERE id=? LIMIT 1');
            $q->execute([$sourceId]);
            $src = $q->fetch() ?: [];
            if (!empty($src['created_at'])) $reportedAt = $src['created_at'];
            if (isset($src['hour_meter_reading']) && is_numeric($src['hour_meter_reading'])) $machineHours = (float)$src['hour_meter_reading'];
        } elseif ($sourceType === 'OPERATOR_REPORT' && $sourceId !== '') {
            $q = db()->prepare('SELECT created_at FROM operator_reports WHERE id=? LIMIT 1');
            $q->execute([$sourceId]);
            $src = $q->fetch() ?: [];
            if (!empty($src['created_at'])) $reportedAt = $src['created_at'];
        } elseif ($sourceType === 'SERVICE_REQUEST' && $sourceId !== '') {
            $q = db()->prepare('SELECT created_at FROM service_requests WHERE id=? LIMIT 1');
            $q->execute([$sourceId]);
            $src = $q->fetch() ?: [];
            if (!empty($src['created_at'])) $reportedAt = $src['created_at'];
        }
        if ($machineHours === null && !empty($row['machine_id'])) {
            $sql = 'SELECT hour_meter_reading FROM checklist_reports WHERE machine_id=?';
            $params = [(string)$row['machine_id']];
            if (!empty($reportedAt)) { $sql .= ' AND created_at<=?'; $params[] = $reportedAt; }
            $sql .= ' ORDER BY created_at DESC LIMIT 1';
            $q = db()->prepare($sql); $q->execute($params); $v = $q->fetchColumn();
            if ($v !== false && $v !== null && is_numeric($v)) $machineHours = (float)$v;
        }
    } catch (Throwable $e) { error_log('Breakdown reported context failed: '.$e->getMessage()); }
    return ['reportedAt'=>$reportedAt,'machineHours'=>$machineHours];
}

function bw_latest_workshop_instruction(string $caseId): array {
    if ($caseId === '') return ['instruction'=>null,'by'=>null,'at'=>null];
    try {
        $q = db()->prepare("SELECT note,actor_name,created_at FROM breakdown_case_events WHERE case_id=? AND action='WORKSHOP_MANAGER_INSTRUCTION' AND COALESCE(TRIM(note),'')<>'' ORDER BY created_at DESC LIMIT 1");
        $q->execute([$caseId]);
        $r = $q->fetch() ?: [];
        return [
            'instruction'=>isset($r['note']) && trim((string)$r['note'])!=='' ? trim((string)$r['note']) : null,
            'by'=>isset($r['actor_name']) && trim((string)$r['actor_name'])!=='' ? trim((string)$r['actor_name']) : null,
            'at'=>$r['created_at'] ?? null,
        ];
    } catch (Throwable $e) {
        error_log('Breakdown workshop instruction lookup failed: '.$e->getMessage());
        return ['instruction'=>null,'by'=>null,'at'=>null];
    }
}

function bw_case_view(array $row): array {
    $stage = (string)$row['current_stage'];
    $jobCardNo = trim((string)($row['job_card_no'] ?? ''));
    $jobCardId = trim((string)($row['job_card_id'] ?? ''));
    $jobStatus = trim((string)($row['job_status'] ?? ''));
    $technicianId = trim((string)($row['technician_id'] ?? ''));
    $technicianName = trim((string)($row['technician_name'] ?? ''));
    if (!empty($row['id']) && ($jobCardNo === '' || $jobCardId === '')) {
        $jobStmt = db()->prepare('SELECT id,job_card_no,status,technician_id,technician_name FROM digital_job_cards WHERE case_id=? ORDER BY created_at ASC LIMIT 1');
        $jobStmt->execute([(string)$row['id']]);
        $jobRow = $jobStmt->fetch() ?: [];
        if ($jobCardId === '') $jobCardId = trim((string)($jobRow['id'] ?? ''));
        if ($jobCardNo === '') $jobCardNo = trim((string)($jobRow['job_card_no'] ?? ''));
        if ($jobStatus === '') $jobStatus = trim((string)($jobRow['status'] ?? ''));
        if ($technicianId === '') $technicianId = trim((string)($jobRow['technician_id'] ?? ''));
        if ($technicianName === '') $technicianName = trim((string)($jobRow['technician_name'] ?? ''));
    }
    $meta = BREAKDOWN_STAGE_META[$stage] ?? ['slaHours'=>0];
    $opened = strtotime((string)$row['opened_at']);
    $stageStart = strtotime((string)$row['stage_started_at']);
    $now = time();
    $breakdownHours = $opened ? max(0, round(($now-$opened)/3600,1)) : 0;
    $stageHours = $stageStart ? max(0, round(($now-$stageStart)/3600,1)) : 0;
    $sla = (float)($meta['slaHours'] ?? 0);
    $delayed = $row['status'] !== 'COMPLETED' && $sla > 0 && $stageHours > $sla;
    $reportedContext = bw_reported_context($row);
    $workshopInstruction = bw_latest_workshop_instruction((string)($row['id'] ?? ''));
    return [
        'id'=>$row['id'],'customerId'=>$row['customer_id'],'machineId'=>$row['machine_id'],
        'customerName'=>$row['customer_name'] ?? null,'machineLabel'=>trim(($row['brand'] ?? '').' '.($row['model'] ?? '')) ?: ($row['machine_type'] ?? 'Machine'),
        'brand'=>$row['brand'] ?? null,'model'=>$row['model'] ?? null,'machineType'=>$row['machine_type'] ?? null,
        'serialNumber'=>$row['serial_number'] ?? null,'fleetNumber'=>trim((string)($row['fleet_number'] ?? '')) ?: null,'title'=>$row['title'],'description'=>$row['description'],
        'sourceType'=>$row['source_type'] ?? 'MANUAL','sourceId'=>$row['source_id'] ?? null,
        'jobCardId'=>$jobCardId !== '' ? $jobCardId : null,'jobCardNo'=>$jobCardNo !== '' ? $jobCardNo : null,'jobStatus'=>$jobStatus !== '' ? $jobStatus : null,
        'technicianId'=>$technicianId !== '' ? $technicianId : null,'technicianName'=>$technicianName !== '' ? $technicianName : null,
        'customerManagesWorkshop'=>!empty($row['is_machinery_admin']),
        'status'=>$row['status'],'stage'=>$stage,'department'=>$row['current_department'],'blockerReason'=>$row['blocker_reason'],
        'openedAt'=>$row['opened_at'],'reportedAt'=>$reportedContext['reportedAt'] ?? $row['opened_at'],
        'machineHours'=>$reportedContext['machineHours'],
        'workshopInstruction'=>$workshopInstruction['instruction'],'workshopInstructionBy'=>$workshopInstruction['by'],'workshopInstructionAt'=>$workshopInstruction['at'],
        'stageStartedAt'=>$row['stage_started_at'],'closedAt'=>$row['closed_at'],
        'breakdownHours'=>$breakdownHours,'breakdownDays'=>round($breakdownHours/24,1),'stageHours'=>$stageHours,
        'slaHours'=>$sla,'delayed'=>$delayed,'delayHours'=>$delayed ? round($stageHours-$sla,1) : 0,
    ];
}

$ctx = bw_context($payload);
if (in_array($ctx['kind'], ['customer','customer-tech'], true) && ($ctx['customerId'] ?? '') !== '') {
    require_customer_department((string)$ctx['customerId'], 'technical', 'Technical / Workshop Department');
}


function bw_report_access(array $ctx): void {
    if ($ctx['kind'] === 'customer-tech') json_error('Workshop Department Report is available to Workshop Manager / Administration.', 403);
    if ($ctx['kind'] === 'customer') {
        if (!$ctx['isOwner'] && !in_array($ctx['role'], ['workshop_manager','admin'], true)) {
            json_error('Only Workshop Manager or Administration can view the Workshop Department Report.', 403);
        }
        return;
    }
    if ($ctx['kind'] === 'belm' && !empty($ctx['isTechnician'])) {
        json_error('Technicians use Job Cards; department analysis is for Workshop Manager / Administration.', 403);
    }
}

function bw_report_range(string $period, string $anchorDate): array {
    $period = strtolower(trim($period));
    if (!in_array($period, ['daily','monthly'], true)) $period = 'daily';
    $anchorDate = trim($anchorDate);
    if (!preg_match('/^\\d{4}-\\d{2}-\\d{2}$/', $anchorDate)) $anchorDate = date('Y-m-d');
    $ts = strtotime($anchorDate . ' 00:00:00');
    if ($ts === false) $ts = time();
    if ($period === 'monthly') {
        $start = date('Y-m-01 00:00:00', $ts);
        $end = date('Y-m-01 00:00:00', strtotime('+1 month', strtotime($start)));
        $label = date('F Y', strtotime($start));
    } else {
        $start = date('Y-m-d 00:00:00', $ts);
        $end = date('Y-m-d 00:00:00', strtotime('+1 day', strtotime($start)));
        $label = date('d M Y', strtotime($start));
    }
    return [$period, $start, $end, $label];
}

function bw_machine_report_range(string $from = '', string $to = ''): array {
    $from = trim($from); $to = trim($to);
    if ($from === '' && $to === '') return [null, null, 'All time'];
    if ($from === '') $from = $to;
    if ($to === '') $to = $from;
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
        json_error('Report dates must use YYYY-MM-DD.', 400);
    }
    $tz = new DateTimeZone('Africa/Dar_es_Salaam');
    try {
        $start = new DateTimeImmutable($from . ' 00:00:00', $tz);
        $endDay = new DateTimeImmutable($to . ' 00:00:00', $tz);
    } catch (Throwable $error) {
        json_error('Report date is invalid.', 400);
    }
    if ($endDay < $start) json_error('Report end date cannot be before start date.', 400);
    return [$start->format(DateTimeInterface::ATOM), $endDay->modify('+1 day')->format(DateTimeInterface::ATOM), $from === $to ? $from : ($from . ' to ' . $to)];
}

function bw_machine_report_access(array $ctx, string $machineId): array {
    $stmt = db()->prepare('SELECT m.id,m.customer_id,m.brand,m.model,m.machine_type,m.serial_number,m.reg_number,c.name AS customer_name,c.is_machinery_admin
                           FROM machines m JOIN customers c ON c.id=m.customer_id
                           WHERE m.id=? AND m.deleted_at IS NULL AND c.deleted_at IS NULL AND c.is_active=1');
    $stmt->execute([$machineId]);
    $machine = $stmt->fetch();
    if (!$machine) json_error('Machine not found.', 404);
    if ($ctx['kind'] === 'customer') {
        if ((string)$machine['customer_id'] !== (string)$ctx['customerId']) json_error('Not allowed.', 403);
        return $machine;
    }
    if ($ctx['kind'] === 'customer-tech') {
        if ((string)$machine['customer_id'] !== (string)$ctx['customerId']) json_error('This machine is not assigned to this Technician.', 403);
        if (empty($machine['is_machinery_admin'])) json_error('Customer Technician access is paused while BELM Service Provider is active.', 403);
        return $machine;
    }
    require_belm_customer_privacy((string)$machine['customer_id'], 'maintenanceRecords', 'internal maintenance and Job Card reports', $machineId);
    if (!empty($ctx['isTechnician'])) {
        $assigned = (string)($ctx['customerId'] ?? '');
        $hasJob = false;
        if (!empty($ctx['actorId'])) {
            $job = db()->prepare('SELECT 1 FROM digital_job_cards WHERE machine_id=? AND technician_id=? LIMIT 1');
            $job->execute([$machineId, (string)$ctx['actorId']]);
            $hasJob = (bool)$job->fetchColumn();
        }
        if ($assigned !== (string)$machine['customer_id'] && !$hasJob) json_error('You are not assigned to this machine.', 403);
    }
    return $machine;
}

function bw_report_scope(array $ctx): array {
    if ($ctx['kind'] === 'customer') {
        $stmt = db()->prepare('SELECT name FROM customers WHERE id=? AND deleted_at IS NULL');
        $stmt->execute([$ctx['customerId']]);
        $name = (string)($stmt->fetchColumn() ?: 'Customer');
        return ['sql' => 'bc.customer_id=?', 'jobSql' => 'j.customer_id=?', 'params' => [$ctx['customerId']], 'jobParams' => [$ctx['customerId']], 'label' => $name];
    }
    return ['sql' => "(c.is_machinery_admin=0 OR bc.source_type='SERVICE_REQUEST')", 'jobSql' => "(c.is_machinery_admin=0 OR bcj.source_type='SERVICE_REQUEST')", 'params' => [], 'jobParams' => [], 'label' => 'BELM Provider + Official Support Work'];
}

function bw_department_report_data(array $ctx, string $period, string $anchorDate): array {
    bw_report_access($ctx);
    [$period, $start, $end, $periodLabel] = bw_report_range($period, $anchorDate);
    $scope = bw_report_scope($ctx);

    $caseBase = ' FROM breakdown_cases bc JOIN customers c ON c.id=bc.customer_id JOIN machines m ON m.id=bc.machine_id WHERE ' . $scope['sql'];
    $jobBase = ' FROM digital_job_cards j JOIN breakdown_cases bcj ON bcj.id=j.case_id JOIN customers c ON c.id=j.customer_id JOIN machines m ON m.id=j.machine_id WHERE ' . $scope['jobSql'];

    $stmt = db()->prepare('SELECT bc.*,c.name customer_name,c.is_machinery_admin,m.brand,m.model,m.machine_type,m.serial_number,m.reg_number,m.fleet_number' . $caseBase . " AND bc.status='OPEN' ORDER BY bc.opened_at ASC");
    $stmt->execute($scope['params']);
    $openRows = $stmt->fetchAll();
    $openCases = [];
    $delayed = 0;
    $bottleneckMap = [];
    foreach ($openRows as $row) {
        $view = bw_case_view($row);
        $openCases[] = $view;
        if ($view['delayed']) $delayed++;
        $dept = (string)($view['department'] ?: 'Unknown');
        if (!isset($bottleneckMap[$dept])) $bottleneckMap[$dept] = ['department'=>$dept,'openCases'=>0,'delayedCases'=>0,'totalWaitHours'=>0.0,'oldestWaitHours'=>0.0];
        $bottleneckMap[$dept]['openCases']++;
        if ($view['delayed']) $bottleneckMap[$dept]['delayedCases']++;
        $bottleneckMap[$dept]['totalWaitHours'] += (float)$view['stageHours'];
        $bottleneckMap[$dept]['oldestWaitHours'] = max($bottleneckMap[$dept]['oldestWaitHours'], (float)$view['stageHours']);
    }
    $bottlenecks = [];
    foreach ($bottleneckMap as $b) {
        $b['avgWaitHours'] = $b['openCases'] ? round($b['totalWaitHours'] / $b['openCases'], 1) : 0;
        unset($b['totalWaitHours']);
        $b['oldestWaitHours'] = round($b['oldestWaitHours'], 1);
        $bottlenecks[] = $b;
    }
    usort($bottlenecks, fn($a,$b) => ($b['delayedCases'] <=> $a['delayedCases']) ?: ($b['openCases'] <=> $a['openCases']) ?: ($b['oldestWaitHours'] <=> $a['oldestWaitHours']));

    $countCase = function(string $extra, array $extraParams=[]) use ($caseBase,$scope): int {
        $q = db()->prepare('SELECT COUNT(*)' . $caseBase . $extra);
        $q->execute(array_merge($scope['params'], $extraParams));
        return (int)$q->fetchColumn();
    };
    $newBreakdowns = $countCase(' AND bc.opened_at>=? AND bc.opened_at<?', [$start,$end]);
    $closedBreakdowns = $countCase(' AND bc.closed_at>=? AND bc.closed_at<?', [$start,$end]);

    $jobStmt = db()->prepare('SELECT j.*,m.brand,m.model,m.machine_type,m.serial_number,m.reg_number' . $jobBase . ' AND ((j.created_at>=? AND j.created_at<?) OR (j.completed_at>=? AND j.completed_at<?)) ORDER BY COALESCE(j.completed_at,j.updated_at,j.created_at) DESC');
    $jobStmt->execute(array_merge($scope['jobParams'], [$start,$end,$start,$end]));
    $jobRows = $jobStmt->fetchAll();

    $createdJobs = 0; $completedJobs = 0; $repeatJobs = 0; $resolutionTotal = 0.0; $resolutionCount = 0;
    $tech = []; $faults = [];
    $recentJobs = [];
    foreach ($jobRows as $j) {
        $startTs = strtotime($start); $endTs = strtotime($end);
        $createdTs = !empty($j['created_at']) ? strtotime((string)$j['created_at']) : false;
        $completedTs = !empty($j['completed_at']) ? strtotime((string)$j['completed_at']) : false;
        $createdIn = $createdTs !== false && $createdTs >= $startTs && $createdTs < $endTs;
        $completedIn = $completedTs !== false && $completedTs >= $startTs && $completedTs < $endTs;
        if ($createdIn) $createdJobs++;
        if ($completedIn) {
            $completedJobs++;
            if (!empty($j['repeat_issue'])) $repeatJobs++;
            if (!empty($j['started_at'])) {
                $h = max(0, (strtotime((string)$j['completed_at']) - strtotime((string)$j['started_at'])) / 3600);
                $resolutionTotal += $h; $resolutionCount++;
            }
            $faultKey = strtolower(trim((string)$j['title']));
            if ($faultKey !== '') {
                if (!isset($faults[$faultKey])) $faults[$faultKey] = ['title'=>$j['title'],'count'=>0,'repeatCount'=>0];
                $faults[$faultKey]['count']++;
                if (!empty($j['repeat_issue'])) $faults[$faultKey]['repeatCount']++;
            }
        }
        $name = trim((string)($j['technician_name'] ?? '')) ?: 'Unassigned';
        if (!isset($tech[$name])) $tech[$name] = ['technicianName'=>$name,'totalJobs'=>0,'completedJobs'=>0,'repeatJobs'=>0,'resolutionTotal'=>0.0,'resolutionCount'=>0];
        if ($createdIn) $tech[$name]['totalJobs']++;
        if ($completedIn) {
            $tech[$name]['completedJobs']++;
            if (!empty($j['repeat_issue'])) $tech[$name]['repeatJobs']++;
            if (!empty($j['started_at'])) {
                $h = max(0, (strtotime((string)$j['completed_at']) - strtotime((string)$j['started_at'])) / 3600);
                $tech[$name]['resolutionTotal'] += $h; $tech[$name]['resolutionCount']++;
            }
        }
        if (count($recentJobs) < 40) {
            $resolution = null;
            if (!empty($j['completed_at']) && !empty($j['started_at'])) $resolution = round(max(0,(strtotime((string)$j['completed_at'])-strtotime((string)$j['started_at']))/3600),1);
            $recentJobs[] = [
                'jobCardNo'=>$j['job_card_no'],'machine'=>trim(($j['brand']??'').' '.($j['model']??'')) ?: ($j['machine_type']??'Machine'),
                'title'=>$j['title'],'technician'=>$name,'status'=>$j['status'],'repeatIssue'=>!empty($j['repeat_issue']),
                'createdAt'=>$j['created_at'],'completedAt'=>$j['completed_at'],'resolutionHours'=>$resolution,
            ];
        }
    }
    $techRows = [];
    foreach ($tech as $t) {
        if ($t['totalJobs']===0 && $t['completedJobs']===0) continue;
        $completionBase = max($t['totalJobs'], $t['completedJobs']);
        $t['completionRate'] = $completionBase ? round($t['completedJobs'] * 100 / $completionBase, 1) : 0;
        $t['firstTimeFixRate'] = $t['completedJobs'] ? round(max(0,$t['completedJobs']-$t['repeatJobs']) * 100 / $t['completedJobs'], 1) : 0;
        $t['avgResolutionHours'] = $t['resolutionCount'] ? round($t['resolutionTotal'] / $t['resolutionCount'], 1) : 0;
        unset($t['resolutionTotal'],$t['resolutionCount']);
        $techRows[] = $t;
    }
    usort($techRows, fn($a,$b) => ($b['completedJobs'] <=> $a['completedJobs']) ?: ($a['repeatJobs'] <=> $b['repeatJobs']));

    $faultRows = array_values($faults);
    usort($faultRows, fn($a,$b) => ($b['count'] <=> $a['count']) ?: ($b['repeatCount'] <=> $a['repeatCount']));
    $faultRows = array_slice($faultRows, 0, 8);

    $waitingAdministration = count(array_filter($openCases, fn($c) => $c['stage']==='BOSS_APPROVAL'));
    $waitingParts = count(array_filter($openCases, fn($c) => in_array($c['stage'], ['STORE_CHECK','PROCUREMENT','ACCOUNTS','PARTS_READY'], true)));
    $avgResolution = $resolutionCount ? round($resolutionTotal/$resolutionCount,1) : 0;
    $firstTimeFix = $completedJobs ? round(max(0,$completedJobs-$repeatJobs)*100/$completedJobs,1) : 0;

    return [
        'period'=>$period,'periodLabel'=>$periodLabel,'start'=>$start,'end'=>$end,'scopeLabel'=>$scope['label'],'generatedAt'=>date('c'),
        'summary'=>[
            'newBreakdowns'=>$newBreakdowns,'closedBreakdowns'=>$closedBreakdowns,'jobCardsCreated'=>$createdJobs,'completedJobs'=>$completedJobs,
            'openBreakdowns'=>count($openCases),'delayedBreakdowns'=>$delayed,'waitingAdministration'=>$waitingAdministration,'waitingParts'=>$waitingParts,
            'repeatJobs'=>$repeatJobs,'firstTimeFixRate'=>$firstTimeFix,'avgResolutionHours'=>$avgResolution,
        ],
        'bottlenecks'=>$bottlenecks,'technicians'=>$techRows,'repeatFaults'=>$faultRows,'recentJobs'=>$recentJobs,
    ];
}


function bw_technician_workload(array $rows): array {
    if (!$rows) return $rows;
    $jobCounts = db()->prepare("SELECT
        SUM(CASE WHEN status NOT IN ('COMPLETED','CANCELLED') THEN 1 ELSE 0 END) AS active_jobs,
        SUM(CASE WHEN status='IN_PROGRESS' THEN 1 ELSE 0 END) AS in_progress,
        SUM(CASE WHEN status='WAITING_FOR_PARTS' THEN 1 ELSE 0 END) AS waiting_parts,
        SUM(CASE WHEN status='COMPLETED' AND DATE(completed_at)=CURRENT_DATE THEN 1 ELSE 0 END) AS completed_today
        FROM digital_job_cards WHERE technician_id=?");
    $activeCases = db()->prepare("SELECT bc.current_stage,bc.stage_started_at,bc.status
        FROM digital_job_cards j JOIN breakdown_cases bc ON bc.id=j.case_id
        WHERE j.technician_id=? AND j.status NOT IN ('COMPLETED','CANCELLED') AND bc.status<>'COMPLETED'");
    foreach ($rows as &$row) {
        $id = (string)($row['id'] ?? '');
        $jobCounts->execute([$id]);
        $c = $jobCounts->fetch() ?: [];
        $active = (int)($c['active_jobs'] ?? 0);
        $delayed = 0;
        $activeCases->execute([$id]);
        foreach ($activeCases->fetchAll() as $caseRow) {
            $stage = (string)($caseRow['current_stage'] ?? '');
            $meta = BREAKDOWN_STAGE_META[$stage] ?? ['slaHours'=>0];
            $sla = (float)($meta['slaHours'] ?? 0);
            $start = !empty($caseRow['stage_started_at']) ? strtotime((string)$caseRow['stage_started_at']) : false;
            if ($sla > 0 && $start && (time()-$start)/3600 > $sla) $delayed++;
        }
        $availability = $active >= 5 ? 'FULL' : ($active >= 3 ? 'BUSY' : 'AVAILABLE');
        $row['activeJobs'] = $active;
        $row['inProgress'] = (int)($c['in_progress'] ?? 0);
        $row['waitingParts'] = (int)($c['waiting_parts'] ?? 0);
        $row['completedToday'] = (int)($c['completed_today'] ?? 0);
        $row['delayedJobs'] = $delayed;
        $row['availability'] = $availability;
        $row['workloadPct'] = min(100, (int)round($active * 20));
        $row['assignmentBlocked'] = $availability === 'FULL';
    }
    unset($row);
    return $rows;
}

if ($method === 'GET' && $action === 'technicians') {
    if (bw_is_technician_actor($ctx)) json_error('Technicians use My Job Cards; technician roster management is restricted.',403);
    $customerId = trim((string)($_GET['customerId'] ?? $ctx['customerId']));
    if (in_array($ctx['kind'],['customer','customer-tech'],true) && $customerId !== $ctx['customerId']) json_error('Not allowed.',403);
    // Customer-side assignment is strictly organization-owned. Customer Admin /
    // Workshop Manager may always see only this customer's own customer-managed
    // Technicians for internal breakdown Job Cards. BELM provider mode does not
    // expose BELM staff here; official SERVICE_REQUEST cards remain BELM-owned.

    if ($ctx['kind']==='belm' && empty($ctx['isTechnician']) && !empty($ctx['canOverrideTechnician'])) {
        // Super Admin / Engineer sees every active BELM-owned Technician.
        // Home-customer labels let them intentionally pick a cross-customer
        // technician and confirm a Temporary Override in the Job Card dialog.
        $stmt = db()->query(
            "SELECT u.id,u.name,u.email,u.is_customer_managed,u.assigned_customer_id, hc.name AS assigned_customer_name
             FROM users u JOIN roles r ON r.id=u.role_id
             LEFT JOIN customers hc ON hc.id=u.assigned_customer_id
             WHERE u.is_active=1 AND u.deleted_at IS NULL
               AND (r.name='Technician' OR EXISTS (
                    SELECT 1 FROM user_roles ur JOIN roles rr ON rr.id=ur.role_id
                    WHERE ur.user_id=u.id AND rr.name='Technician' AND rr.deleted_at IS NULL
               ))
               AND u.is_customer_managed=0
             ORDER BY u.name"
        );
        $rows=$stmt->fetchAll();
        foreach($rows as &$row){
            $row['assignedCustomerId']=$row['assigned_customer_id'];
            $row['assignedCustomerName']=$row['assigned_customer_name'];
            $row['temporaryForCustomer']=!empty($row['assigned_customer_id']) && $customerId!=='' && (string)$row['assigned_customer_id']!==$customerId;
            unset($row['assigned_customer_id'],$row['assigned_customer_name']);
        }
        unset($row);
        json_out(bw_technician_workload($rows));
    }

    $sql = "SELECT u.id,u.name,u.email,u.is_customer_managed,u.assigned_customer_id, hc.name AS assigned_customer_name
            FROM users u JOIN roles r ON r.id=u.role_id
            LEFT JOIN customers hc ON hc.id=u.assigned_customer_id
            WHERE u.is_active=1 AND u.deleted_at IS NULL AND u.assigned_customer_id=?
              AND (r.name='Technician' OR EXISTS (
                   SELECT 1 FROM user_roles ur JOIN roles rr ON rr.id=ur.role_id
                   WHERE ur.user_id=u.id AND rr.name='Technician' AND rr.deleted_at IS NULL
              ))";
    if ($ctx['kind']==='belm') $sql .= ' AND u.is_customer_managed=0';
    else $sql .= ' AND u.is_customer_managed=1';
    $sql .= ' ORDER BY u.name';
    $stmt=db()->prepare($sql); $stmt->execute([$customerId]);
    $rows=$stmt->fetchAll();
    foreach($rows as &$row){
        $row['assignedCustomerId']=$row['assigned_customer_id'];
        $row['assignedCustomerName']=$row['assigned_customer_name'];
        $row['temporaryForCustomer']=false;
        unset($row['assigned_customer_id'],$row['assigned_customer_name']);
    }
    unset($row);
    json_out(bw_technician_workload($rows));
}

if ($method === 'GET' && $action === 'performance') {
    if (bw_is_technician_actor($ctx)) json_error('Technicians can view their own Job Card reports, not department performance.',403);
    $customerId = trim((string)($_GET['customerId'] ?? $ctx['customerId']));
    if (in_array($ctx['kind'],['customer','customer-tech'],true) && $customerId !== $ctx['customerId']) json_error('Not allowed.',403);
    if ($customerId==='' && $ctx['kind']==='belm') {
        $stmt=db()->prepare(
            "SELECT j.technician_id, COALESCE(j.technician_name,'Unassigned') technician_name,
                    COUNT(*) total_jobs,
                    COUNT(*) FILTER (WHERE j.status='COMPLETED') completed_jobs,
                    COUNT(*) FILTER (WHERE j.repeat_issue=1) repeat_jobs,
                    ROUND((AVG(EXTRACT(EPOCH FROM (j.completed_at-j.started_at))/3600.0) FILTER (WHERE j.completed_at IS NOT NULL AND j.started_at IS NOT NULL))::numeric,1) avg_hours
             FROM digital_job_cards j JOIN breakdown_cases bc ON bc.id=j.case_id JOIN customers c ON c.id=j.customer_id
             WHERE (c.is_machinery_admin=0 OR bc.source_type='SERVICE_REQUEST') GROUP BY j.technician_id,j.technician_name ORDER BY completed_jobs DESC,total_jobs DESC"
        );
        $stmt->execute();
    } else {
        $stmt=db()->prepare(
            "SELECT technician_id, COALESCE(technician_name,'Unassigned') technician_name,
                    COUNT(*) total_jobs,
                    COUNT(*) FILTER (WHERE status='COMPLETED') completed_jobs,
                    COUNT(*) FILTER (WHERE repeat_issue=1) repeat_jobs,
                    ROUND((AVG(EXTRACT(EPOCH FROM (completed_at-started_at))/3600.0) FILTER (WHERE completed_at IS NOT NULL AND started_at IS NOT NULL))::numeric,1) avg_hours
             FROM digital_job_cards WHERE customer_id=? GROUP BY technician_id,technician_name ORDER BY completed_jobs DESC,total_jobs DESC"
        );
        $stmt->execute([$customerId]);
    }
    $rows=[];
    foreach($stmt->fetchAll() as $r){
        $total=(int)$r['total_jobs']; $completed=(int)$r['completed_jobs']; $repeat=(int)$r['repeat_jobs'];
        $rows[]=['technicianId'=>$r['technician_id'],'technicianName'=>$r['technician_name'],'totalJobs'=>$total,'completedJobs'=>$completed,
            'completionRate'=>$total?round($completed*100/$total,1):0,'repeatJobs'=>$repeat,
            'firstTimeFixRate'=>$completed?round(max(0,$completed-$repeat)*100/$completed,1):0,'avgResolutionHours'=>(float)($r['avg_hours'] ?? 0)];
    }
    json_out($rows);
}


if ($method === 'GET' && $action === 'department-report') {
    $period = (string)($_GET['period'] ?? 'daily');
    $date = (string)($_GET['date'] ?? date('Y-m-d'));
    json_out(bw_department_report_data($ctx, $period, $date));
}

if ($method === 'GET' && $action === 'department-report-pdf') {
    $period = (string)($_GET['period'] ?? 'daily');
    $date = (string)($_GET['date'] ?? date('Y-m-d'));
    $r = bw_department_report_data($ctx, $period, $date);
    $s = $r['summary'];
    $rows = [
        ['WORKSHOP SUMMARY'],
        ['New breakdowns', (string)$s['newBreakdowns']],
        ['Breakdowns closed', (string)$s['closedBreakdowns']],
        ['Job Cards created', (string)$s['jobCardsCreated']],
        ['Jobs completed', (string)$s['completedJobs']],
        ['Open breakdowns now', (string)$s['openBreakdowns']],
        ['Service Level Agreement', (string)$s['delayedBreakdowns']],
        ['Waiting Administration approval', (string)$s['waitingAdministration']],
        ['Waiting Store / Procurement / Accounts', (string)$s['waitingParts']],
        ['First-time-fix rate', $s['firstTimeFixRate'].'%'],
        ['Repeat / rework jobs', (string)$s['repeatJobs']],
        ['Average repair resolution', $s['avgResolutionHours'].' hrs'],
        [''],
        ['CURRENT BOTTLENECKS'],
        ['Department','Open','Delayed','Avg wait','Oldest wait'],
    ];
    foreach ($r['bottlenecks'] as $b) $rows[] = [$b['department'],(string)$b['openCases'],(string)$b['delayedCases'],$b['avgWaitHours'].' hrs',$b['oldestWaitHours'].' hrs'];
    $rows[]=['']; $rows[]=['TECHNICIAN PERFORMANCE'];
    $rows[]=['Technician','Jobs','Completed','Completion','First-time fix','Avg hrs','Repeat'];
    foreach ($r['technicians'] as $t) $rows[] = [$t['technicianName'],(string)$t['totalJobs'],(string)$t['completedJobs'],$t['completionRate'].'%',$t['firstTimeFixRate'].'%',$t['avgResolutionHours'].' hrs',(string)$t['repeatJobs']];
    $rows[]=['']; $rows[]=['REPEAT / COMMON FAULTS'];
    $rows[]=['Fault / Job','Completed','Repeat'];
    foreach ($r['repeatFaults'] as $f) $rows[] = [$f['title'],(string)$f['count'],(string)$f['repeatCount']];
    $rows[]=['']; $rows[]=['JOB CARD ACTIVITY'];
    $rows[]=['Job Card','Machine','Technician','Status','Resolution','Repeat'];
    foreach ($r['recentJobs'] as $j) $rows[] = [$j['jobCardNo'],$j['machine'],$j['technician'],$j['status'],$j['resolutionHours']===null?'-':$j['resolutionHours'].' hrs',$j['repeatIssue']?'YES':'NO'];
    $filePeriod = $r['period']==='monthly' ? date('Y-m', strtotime($r['start'])) : date('Y-m-d', strtotime($r['start']));
    output_table_pdf('Workshop-Department-Report-'.$filePeriod.'.pdf','WORKSHOP DEPARTMENT REPORT',[
        'Company / scope: '.$r['scopeLabel'],
        'Period: '.$r['periodLabel'].' ('.strtoupper($r['period']).')',
        'Generated: '.date('d/m/Y H:i'),
        'Operational analysis from Breakdown Workflow and Digital Job Cards',
    ],$rows);
}

// V274 - staff-side "Job Card / Daily Report" list for one machine, used
// by the "Checkup Report" button on the Message Customer dialog and
// anywhere else BELM Admin wants a machine's Job Card history without
// digging through Breakdown Workflow case by case. Read-only, never
// deletes or hides anything.
if ($method === 'GET' && $action === 'machine-job-cards' && !empty($_GET['machineId'])) {
    if (bw_is_technician_actor($ctx)) json_error('Technicians can view only their assigned Job Cards in My Job Cards.',403);
    $machineId = trim((string)$_GET['machineId']);
    bw_machine_report_access($ctx, $machineId);
    [$fromTs, $toTs] = bw_machine_report_range((string)($_GET['from'] ?? ''), (string)($_GET['to'] ?? ''));
    $sql = 'SELECT id, job_card_no, title, fault_description, status, technician_name,
                   diagnosis, work_done, test_result, completion_note, repeat_issue,
                   started_at, completed_at, created_at
            FROM digital_job_cards WHERE machine_id = ?';
    $params = [$machineId];
    if ($fromTs !== null) { $sql .= ' AND created_at >= ?'; $params[] = $fromTs; }
    if ($toTs !== null) { $sql .= ' AND created_at < ?'; $params[] = $toTs; }
    $sql .= ' ORDER BY created_at DESC LIMIT 250';
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    json_out($stmt->fetchAll());
}

if ($method === 'GET' && $action === 'machine-job-cards-pdf' && !empty($_GET['machineId'])) {
    if (bw_is_technician_actor($ctx)) json_error('Technicians can download only their assigned Job Card/Report PDFs.',403);
    $machineId = trim((string)$_GET['machineId']);
    $machine = bw_machine_report_access($ctx, $machineId);
    [$fromTs, $toTs, $periodLabel] = bw_machine_report_range((string)($_GET['from'] ?? ''), (string)($_GET['to'] ?? ''));
    $sql = 'SELECT job_card_no,title,status,technician_name,created_at,completed_at
            FROM digital_job_cards WHERE machine_id=?';
    $params = [$machineId];
    if ($fromTs !== null) { $sql .= ' AND created_at >= ?'; $params[] = $fromTs; }
    if ($toTs !== null) { $sql .= ' AND created_at < ?'; $params[] = $toTs; }
    $sql .= ' ORDER BY created_at DESC';
    $stmt = db()->prepare($sql); $stmt->execute($params); $jobCards = $stmt->fetchAll();
    $rows = array_map(static fn(array $jc): array => [
        (string)$jc['job_card_no'],
        (string)$jc['title'],
        (string)$jc['status'],
        (string)($jc['technician_name'] ?: 'Unassigned'),
        display_date_billing($jc['created_at']),
    ], $jobCards);
    $machineLabel = trim((string)($machine['brand'] ?? '') . ' ' . (string)($machine['model'] ?? '')) ?: 'Machine';
    output_table_pdf(
        'BELM-job-card-report-history.pdf',
        'JOB CARD REPORTS',
        [
            'Customer: ' . (string)($machine['customer_name'] ?? 'Customer'),
            'Machine: ' . $machineLabel,
            'Serial / Registration: ' . (string)($machine['serial_number'] ?: ($machine['reg_number'] ?: 'Not recorded')),
            'Period: ' . $periodLabel,
            'Job Card  |  Title  |  Status  |  Technician  |  Date',
        ],
        $rows
    );
}

// V416 - machine-specific operational analysis for the Machine Report Center.
// The scope is deliberately ONE machine; no fleet/customer totals are mixed in.
if ($method === 'GET' && $action === 'machine-analysis-pdf' && !empty($_GET['machineId'])) {
    if (bw_is_technician_actor($ctx)) json_error('Technicians can download only their assigned Job Card/Report PDFs.',403);
    $machineId = trim((string)$_GET['machineId']);
    $machine = bw_machine_report_access($ctx, $machineId);
    [$fromTs, $toTs, $periodLabel] = bw_machine_report_range((string)($_GET['from'] ?? ''), (string)($_GET['to'] ?? ''));

    $checkSql = 'SELECT overall_status,hour_meter_reading,created_at FROM checklist_reports WHERE machine_id=?';
    $checkParams = [$machineId];
    if ($fromTs !== null) { $checkSql .= ' AND created_at >= ?'; $checkParams[] = $fromTs; }
    if ($toTs !== null) { $checkSql .= ' AND created_at < ?'; $checkParams[] = $toTs; }
    $checkSql .= ' ORDER BY created_at DESC';
    $stmt = db()->prepare($checkSql); $stmt->execute($checkParams); $checks = $stmt->fetchAll();

    $jobSql = 'SELECT title,fault_description,status,repeat_issue,started_at,completed_at,created_at FROM digital_job_cards WHERE machine_id=?';
    $jobParams = [$machineId];
    if ($fromTs !== null) { $jobSql .= ' AND created_at >= ?'; $jobParams[] = $fromTs; }
    if ($toTs !== null) { $jobSql .= ' AND created_at < ?'; $jobParams[] = $toTs; }
    $jobSql .= ' ORDER BY created_at DESC';
    $stmt = db()->prepare($jobSql); $stmt->execute($jobParams); $jobs = $stmt->fetchAll();

    $opSql = 'SELECT status,created_at FROM operator_reports WHERE machine_id=?';
    $opParams = [$machineId];
    if ($fromTs !== null) { $opSql .= ' AND created_at >= ?'; $opParams[] = $fromTs; }
    if ($toTs !== null) { $opSql .= ' AND created_at < ?'; $opParams[] = $toTs; }
    $opSql .= ' ORDER BY created_at DESC';
    $stmt = db()->prepare($opSql); $stmt->execute($opParams); $operatorReports = $stmt->fetchAll();

    $completed = array_values(array_filter($jobs, static fn(array $j): bool => strtoupper((string)$j['status']) === 'COMPLETED'));
    $openJobs = array_values(array_filter($jobs, static fn(array $j): bool => !in_array(strtoupper((string)$j['status']), ['COMPLETED','CANCELLED'], true)));
    $repeatJobs = array_values(array_filter($completed, static fn(array $j): bool => !empty($j['repeat_issue'])));
    $firstFixCount = max(0, count($completed) - count($repeatJobs));
    $firstFixRate = count($completed) ? (int)round(($firstFixCount / count($completed)) * 100) : 0;
    $completionRate = count($jobs) ? (int)round((count($completed) / count($jobs)) * 100) : 0;

    $redChecks = 0; $yellowChecks = 0; $hours = [];
    foreach ($checks as $check) {
        $st = strtoupper((string)($check['overall_status'] ?? ''));
        if (in_array($st, ['RED','CRITICAL'], true)) $redChecks++;
        if (in_array($st, ['YELLOW','ATTENTION'], true)) $yellowChecks++;
        if ($check['hour_meter_reading'] !== null && is_numeric($check['hour_meter_reading'])) $hours[] = (float)$check['hour_meter_reading'];
    }
    $latestHours = count($hours) ? $hours[0] : null;
    $oldestHours = count($hours) ? $hours[count($hours)-1] : null;
    $hoursMovement = ($latestHours !== null && $oldestHours !== null) ? max(0, $latestHours - $oldestHours) : null;
    $latestCondition = count($checks) ? strtoupper((string)($checks[0]['overall_status'] ?: 'GREEN')) : 'NOT CHECKED';

    $resolutionHours = [];
    foreach ($completed as $job) {
        $startRaw = $job['started_at'] ?: $job['created_at'];
        $endRaw = $job['completed_at'] ?: null;
        if (!$startRaw || !$endRaw) continue;
        try {
            $start = new DateTimeImmutable((string)$startRaw);
            $end = new DateTimeImmutable((string)$endRaw);
            if ($end >= $start) $resolutionHours[] = ($end->getTimestamp() - $start->getTimestamp()) / 3600;
        } catch (Throwable $ignored) {}
    }
    $avgRepair = count($resolutionHours) ? array_sum($resolutionHours) / count($resolutionHours) : 0;

    $openOperator = 0; $resolvedOperator = 0;
    foreach ($operatorReports as $report) {
        if (strtoupper((string)$report['status']) === 'RESOLVED') $resolvedOperator++; else $openOperator++;
    }
    $operatorResolutionRate = count($operatorReports) ? (int)round(($resolvedOperator / count($operatorReports)) * 100) : 0;

    $faults = [];
    foreach ($jobs as $job) {
        $name = trim((string)($job['fault_description'] ?: $job['title'] ?: 'Unspecified job'));
        if ($name === '') $name = 'Unspecified job';
        if (!isset($faults[$name])) $faults[$name] = ['count'=>0,'repeat'=>0];
        $faults[$name]['count']++;
        if (!empty($job['repeat_issue'])) $faults[$name]['repeat']++;
    }
    uasort($faults, static function(array $a, array $b): int {
        if ($a['count'] === $b['count']) return $b['repeat'] <=> $a['repeat'];
        return $b['count'] <=> $a['count'];
    });

    $rows = [
        ['MACHINE HEALTH'],
        ['Latest condition', $latestCondition],
        ['Checklist reports', (string)count($checks)],
        ["Red / Don't operate", (string)$redChecks],
        ['Yellow / Attention', (string)$yellowChecks],
        ['Latest hour meter', $latestHours === null ? '-' : (string)$latestHours],
        ['Hours movement in period', $hoursMovement === null ? '-' : round($hoursMovement,1).' HRS'],
        [''],
        ['JOB CARD PERFORMANCE'],
        ['Job Cards', (string)count($jobs)],
        ['Open Job Cards', (string)count($openJobs)],
        ['Completed', (string)count($completed)],
        ['Completion rate', $completionRate.'%'],
        ['First-time fix', $firstFixRate.'%'],
        ['Repeat / rework', (string)count($repeatJobs)],
        ['Average repair time', round($avgRepair,1).' hrs'],
        [''],
        ['OPERATOR REPORTS'],
        ['Total reports', (string)count($operatorReports)],
        ['Open', (string)$openOperator],
        ['Resolved', (string)$resolvedOperator],
        ['Resolution rate', $operatorResolutionRate.'%'],
        [''],
        ['COMMON FAULTS / JOBS'],
        ['Fault / Job','Occurrences','Repeat / rework'],
    ];
    $i=0;
    foreach ($faults as $name => $info) {
        $rows[] = [$name,(string)$info['count'],(string)$info['repeat']];
        if (++$i >= 10) break;
    }
    if ($i===0) $rows[]=['No Job Card fault history in this period','0','0'];

    $machineLabel = trim((string)($machine['brand'] ?? '') . ' ' . (string)($machine['model'] ?? '')) ?: 'Machine';
    $safeMachine = preg_replace('/[^A-Za-z0-9_-]+/', '-', $machineLabel);
    output_table_pdf(
        'BELM-machine-analysis-' . $safeMachine . '.pdf',
        'MACHINE ANALYSIS',
        [
            'Customer: ' . (string)($machine['customer_name'] ?? 'Customer'),
            'Machine: ' . $machineLabel,
            'Serial / Registration: ' . (string)($machine['serial_number'] ?: ($machine['reg_number'] ?: 'Not recorded')),
            'Period: ' . $periodLabel,
            'Scope: THIS MACHINE ONLY',
        ],
        $rows
    );
}

if ($method === 'GET' && $action === 'job-card-pdf' && $id !== '') {
    $stmt=db()->prepare('SELECT j.*,bc.customer_id,bc.current_stage,bc.source_type,c.name customer_name,c.address AS customer_address,c.is_machinery_admin,m.brand,m.model,m.machine_type,m.serial_number,m.reg_number,
        u.assigned_customer_id AS technician_home_customer_id,hc.name AS technician_home_customer_name
        FROM digital_job_cards j JOIN breakdown_cases bc ON bc.id=j.case_id JOIN customers c ON c.id=j.customer_id JOIN machines m ON m.id=j.machine_id
        LEFT JOIN users u ON u.id=j.technician_id LEFT JOIN customers hc ON hc.id=u.assigned_customer_id WHERE j.id=?');
    $stmt->execute([$id]); $job=$stmt->fetch(); if(!$job)json_error('Job Card not found.',404); bw_case_access($ctx,$job['case_id']); bw_require_assigned_job($ctx,$job);
    $rows=[
        ['Job Card', $job['job_card_no']],
        ['Customer', $job['customer_name']],
        ['Machine', trim(($job['brand']??'').' '.($job['model']??''))],
        ['Machine Type', $job['machine_type']??''],
        ['Serial / Reg', $job['serial_number'] ?: ($job['reg_number'] ?: '-')],
        ['Status', $job['status']],
        ['Priority', $job['priority'] ?: 'NORMAL'],
        ['Due Date', !empty($job['due_date']) ? display_date_billing($job['due_date']) : '-'],
        ['Job Location', trim((string)($job['job_location'] ?? '')) ?: (trim((string)($job['customer_address'] ?? '')) ?: '-')],
        ['Issued By', $job['issued_by_name'] ?: ($job['generated_by_name'] ?: $job['customer_name'])],
        ['Issued At', display_date_billing($job['issued_at'] ?: $job['created_at'])],
        ['Technician', $job['technician_name'] ?: 'Unassigned'],
        ['Assignment', !empty($job['technician_id']) && !empty($job['technician_home_customer_id']) && (string)$job['technician_home_customer_id'] !== (string)$job['customer_id']
            ? 'TEMPORARY OVERRIDE - Home: '.($job['technician_home_customer_name'] ?: 'Other customer')
            : 'Normal / home-customer assignment'],
        ['Fault', $job['fault_description']],
        ['Diagnosis', $job['diagnosis'] ?: '-'],
        ['Work Done', $job['work_done'] ?: '-'],
        ['Test Result', $job['test_result'] ?: '-'],
        ['Completion Note', $job['completion_note'] ?: '-'],
        ['Repeat / Rework', !empty($job['repeat_issue']) ? 'YES' : 'NO'],
        ['Started', display_date_billing($job['started_at'])],
        ['Submitted for Approval', display_date_billing($job['technician_submitted_at'] ?? null)],
        ['Reviewed By', $job['reviewed_by_name'] ?: '-'],
        ['Review Note', $job['review_note'] ?: '-'],
        ['Completed', display_date_billing($job['completed_at'])],
        ['Customer Sign-Off', !empty($job['signed_copy_data']) ? 'SIGNED COPY UPLOADED - '.($job['customer_signed_by_name'] ?: 'Customer') : 'WAITING CUSTOMER SIGNATURE'],
        ['Billing / Procurement', $job['billing_status'] ?: 'NOT_READY'],
        ['', ''],
        ['Technician Signature', '_________________________  Date: ______________'],
        ['Customer / Supervisor Signature', '_________________________  Date: ______________'],
        ['Issued By', ($job['issued_by_name'] ?: ($job['generated_by_name'] ?: $job['customer_name'])) . '  Date: ' . display_date_billing($job['issued_at'] ?: $job['created_at'])],
    ];
    $customerOwnedInternalJob = !empty($job['is_machinery_admin']) && strtoupper((string)($job['source_type'] ?? '')) !== 'SERVICE_REQUEST';
    $jobWatermark = $customerOwnedInternalJob ? pdf_customer_watermark((string)$job['customer_id']) : null;
    output_table_pdf('BELM-'.$job['job_card_no'].'.pdf','DIGITAL JOB CARD',[
        'Generated: '.date('d/m/Y H:i'),
        $customerOwnedInternalJob ? 'PORTAL-CWM customer workshop record' : 'Breakdown process record - BELM Operations Portal',
        'Print, sign, and keep this copy for office records.',
    ],$rows,$jobWatermark);
}

if ($method === 'PUT' && $action === 'signed-job-card' && $id !== '') {
    if ($ctx['kind'] !== 'belm' || !empty($ctx['isTechnician'])) {
        json_error('BELM Workshop / Administration must upload the customer-signed Job Card.', 403);
    }
    $stmt=db()->prepare('SELECT * FROM digital_job_cards WHERE id=?');
    $stmt->execute([$id]);
    $job=$stmt->fetch();
    if(!$job) json_error('Job Card not found.',404);
    $case=bw_case_access($ctx,(string)$job['case_id']);
    if (($case['source_type'] ?? '') !== 'SERVICE_REQUEST') {
        json_error('Customer signed-copy upload is used for BELM Job Cards.', 422);
    }
    if (strtoupper((string)$job['status']) !== 'COMPLETED') {
        json_error('Complete the Technician Job Card before uploading the customer-signed copy.', 409);
    }
    if (strtoupper((string)($case['status'] ?? '')) !== 'COMPLETED') {
        json_error('Workshop testing must be completed and the machine returned to service before the signed Job Card is uploaded.', 409);
    }
    $b=body();
    $signedBy=trim((string)($b['signedByName']??''));
    $fileData=trim((string)($b['fileData']??''));
    $fileName=trim((string)($b['fileName']??''));
    if($signedBy==='') json_error('Enter the customer / supervisor name who signed the Job Card.');
    if($fileData==='') json_error('Choose the signed Job Card PDF or photo.');
    [$copyData,$copyMime,$copyName]=bw_signed_copy_upload($fileData,$fileName);
    db()->prepare(
        "UPDATE digital_job_cards SET customer_signed_by_name=?,customer_signed_at=NOW(),signed_copy_data=?,signed_copy_mime=?,signed_copy_name=?,signed_uploaded_by_name=?,signed_uploaded_at=NOW(),billing_status='READY_FOR_PROCUREMENT',updated_at=NOW() WHERE id=?"
    )->execute([$signedBy,$copyData,$copyMime,$copyName,$ctx['actorName'],$id]);
    bw_log((string)$job['case_id'],'COMPLETED','Procurement','Customer-signed Job Card uploaded - ready for Proforma / Invoice','Signed by '.$signedBy.'; uploaded by '.$ctx['actorName'],$ctx);
    try {
        customer_send_team_alert((string)$job['customer_id'],['machine-expenses'], 'SIGNED JOB CARD READY FOR PROCUREMENT - '.$job['job_card_no'],
            "Job Card {$job['job_card_no']} is complete and the customer-signed copy has been uploaded. Procurement can now follow Proforma / Invoice status.", true);
    } catch(Throwable $ignored) {}
    json_out(['ok'=>true,'billingStatus'=>'READY_FOR_PROCUREMENT','message'=>'Signed Job Card uploaded. Procurement / Billing follow-up is now active.']);
}

if ($method === 'GET' && $action === 'signed-job-card-file' && $id !== '') {
    $stmt=db()->prepare('SELECT id,case_id,job_card_no,technician_id,signed_copy_data,signed_copy_mime,signed_copy_name FROM digital_job_cards WHERE id=?');
    $stmt->execute([$id]);
    $job=$stmt->fetch();
    if(!$job) json_error('Job Card not found.',404);
    bw_case_access($ctx,(string)$job['case_id']);
    bw_require_assigned_job($ctx,$job);
    if(empty($job['signed_copy_data'])) json_error('Signed Job Card has not been uploaded yet.',404);
    $binary=base64_decode((string)$job['signed_copy_data'],true);
    if($binary===false) json_error('Signed Job Card file is damaged.',500);
    $mime=in_array((string)$job['signed_copy_mime'],['application/pdf','image/jpeg','image/png','image/webp'],true)?(string)$job['signed_copy_mime']:'application/pdf';
    $name=preg_replace('/[^A-Za-z0-9._-]+/','-',(string)($job['signed_copy_name']?:('Signed-'.$job['job_card_no'].'.pdf')));
    header('Content-Type: '.$mime);
    header('Content-Length: '.strlen($binary));
    header('Content-Disposition: '.(!empty($_GET['download'])?'attachment':'inline').'; filename="'.$name.'"');
    echo $binary; exit;
}

if ($method === 'GET' && $action === 'technician-jobs') {
    $isTechActor = !empty($ctx['isTechnician']) || ($ctx['kind']==='customer' && $ctx['role']==='technician');
    if(!$isTechActor) json_error('Technician login required.',403);
    $actorId=trim((string)($ctx['actorId']??''));
    if($actorId==='') json_error('Technician account identity is missing. Please log in again.',401);

    // V342 self-heal: Job Card assignment and Digital Job Card assignment
    // are one operational record. If an older/interrupted sync left the Job Card
    // without technician_id, repair it when that source request is assigned to
    // the logged-in Technician. Do not overwrite an explicit different assignee.
    try {
        db()->prepare(
            "UPDATE digital_job_cards j
             SET technician_id=sr.assigned_to_id,
                 technician_name=COALESCE(NULLIF(TRIM(u.name),''),NULLIF(TRIM(j.technician_name),''),?),
                 status=CASE WHEN UPPER(COALESCE(j.status,'')) IN ('OPEN','RECEIVED') THEN 'ASSIGNED' ELSE j.status END,
                 updated_at=NOW()
             FROM breakdown_cases bc
             JOIN service_requests sr ON bc.source_type='SERVICE_REQUEST' AND sr.id=bc.source_id
             LEFT JOIN users u ON u.id=sr.assigned_to_id
             WHERE j.case_id=bc.id
               AND sr.assigned_to_id=?
               AND j.technician_id IS NULL
               AND UPPER(COALESCE(j.status,''))<>'CANCELLED'"
        )->execute([(string)($ctx['actorName']??'Technician'),$actorId]);
        db()->prepare(
            "UPDATE digital_job_cards SET technician_name=?,updated_at=NOW()
             WHERE technician_id=? AND COALESCE(TRIM(technician_name),'')=''"
        )->execute([(string)($ctx['actorName']??'Technician'),$actorId]);
    } catch(Throwable $e) {
        error_log('Technician Job Card assignment recovery failed: '.$e->getMessage());
    }

    $params=[$actorId,$actorId];
    $where=["(j.technician_id=? OR (j.technician_id IS NULL AND bc.source_type='SERVICE_REQUEST' AND EXISTS (SELECT 1 FROM service_requests sr_fix WHERE sr_fix.id=bc.source_id AND sr_fix.assigned_to_id=?)))"];
    if($ctx['kind']==='customer') { $where[]='j.customer_id=?'; $params[]=$ctx['customerId']; }
    $machineId=trim((string)($_GET['machineId']??''));
    if($machineId!==''){ $where[]='j.machine_id=?'; $params[]=$machineId; }
    $stmt=db()->prepare(
        "SELECT j.id,j.case_id,j.customer_id,j.machine_id,j.job_card_no,j.title,j.fault_description,j.status,
                j.technician_id,j.technician_name,j.priority,j.due_date,j.job_location,j.diagnosis,j.work_done,j.test_result,j.completion_note,j.repeat_issue,
                j.issued_by_name,j.issued_by_type,j.issued_at,j.received_at,j.started_at,j.technician_submitted_at,j.reviewed_at,j.reviewed_by_name,j.review_note,j.completed_at,j.created_at,j.updated_at,
                bc.status AS case_status,bc.current_stage,bc.current_department,bc.blocker_reason,bc.source_type,bc.source_id,
                c.name AS customer_name,c.address AS customer_address,m.brand,m.model,m.machine_type,m.serial_number,m.reg_number,
                (SELECT COUNT(*) FROM breakdown_spare_requests sr WHERE sr.job_card_id=j.id AND sr.status NOT IN ('REJECTED','PARTS_READY')) AS open_spare_requests,
                (SELECT string_agg(sr.spare_name, ', ' ORDER BY sr.requested_at) FROM breakdown_spare_requests sr WHERE sr.job_card_id=j.id AND sr.status NOT IN ('REJECTED','PARTS_READY')) AS required_spare
         FROM digital_job_cards j
         JOIN breakdown_cases bc ON bc.id=j.case_id
         JOIN customers c ON c.id=j.customer_id
         JOIN machines m ON m.id=j.machine_id
         WHERE ".implode(' AND ',$where)."
         ORDER BY CASE WHEN j.status='COMPLETED' THEN 1 ELSE 0 END, COALESCE(j.due_date,DATE '9999-12-31'), j.created_at DESC"
    );
    $stmt->execute($params); $rows=$stmt->fetchAll();
    foreach($rows as &$row){
        $row['machineLabel']=trim(($row['brand']??'').' '.($row['model']??'')) ?: ($row['machine_type']??'Machine');
        $row['openSpareRequests']=(int)($row['open_spare_requests']??0);
        $row['requiredSpare']=trim((string)($row['required_spare']??''));
        $row['assignedTechnicianId']=$row['technician_id']??null;
        $row['assignedTechnicianName']=trim((string)($row['technician_name']??'')) ?: (string)($ctx['actorName']??'Technician');
        // V343 portable field dispatch: every assigned Job Card carries the work site.
        $row['jobLocation']=trim((string)($row['job_location']??'')) ?: trim((string)($row['customer_address']??''));
        $row['remoteDispatch']=!empty($row['jobLocation']);
        unset($row['open_spare_requests'],$row['required_spare']);
    }
    unset($row);
    json_out($rows);
}

if ($method === 'GET' && $action === 'case' && $id !== '') {
    if (bw_is_technician_actor($ctx)) json_error('Technicians use My Job Cards; full Maintenance Process detail is restricted.',403);
    $case=bw_case_access($ctx,$id);
    $events=db()->prepare('SELECT stage,department,action,note,actor_name,created_at FROM breakdown_case_events WHERE case_id=? ORDER BY created_at ASC');
    $events->execute([$id]);
    $spares=db()->prepare('SELECT * FROM breakdown_spare_requests WHERE case_id=? ORDER BY requested_at ASC'); $spares->execute([$id]);
    $jobs=db()->prepare('SELECT j.*,u.name AS technician_account_name,u.assigned_customer_id AS technician_home_customer_id,hc.name AS technician_home_customer_name
        FROM digital_job_cards j LEFT JOIN users u ON u.id=j.technician_id LEFT JOIN customers hc ON hc.id=u.assigned_customer_id
        WHERE j.case_id=? ORDER BY j.created_at DESC'); $jobs->execute([$id]);
    $jobRows=$jobs->fetchAll();

    // V336: an older/interrupted Job Card may already be ASSIGNED while
    // the linked Job Card row is missing its copied Technician name/id. The
    // Job Card assignment remains authoritative for that legacy case, so
    // expose it as the effective assignment instead of showing "Select Technician".
    $sourceTechnicianId=''; $sourceTechnicianName='';
    if (strtoupper((string)($case['source_type'] ?? '')) === 'SERVICE_REQUEST' && !empty($case['source_id'])) {
        $sourceTech=db()->prepare('SELECT sr.assigned_to_id,u.name AS assigned_to_name FROM service_requests sr LEFT JOIN users u ON u.id=sr.assigned_to_id WHERE sr.id=? LIMIT 1');
        $sourceTech->execute([(string)$case['source_id']]);
        $sourceTechRow=$sourceTech->fetch() ?: [];
        $sourceTechnicianId=trim((string)($sourceTechRow['assigned_to_id'] ?? ''));
        $sourceTechnicianName=trim((string)($sourceTechRow['assigned_to_name'] ?? ''));
    }
    foreach($jobRows as &$jobRow){
        $jobTechId=trim((string)($jobRow['technician_id'] ?? ''));
        $jobTechName=trim((string)($jobRow['technician_name'] ?? ''));
        if ($jobTechName==='' && $jobTechId!=='') {
            $jobTechName=trim((string)($jobRow['technician_account_name'] ?? ''));
        }
        $jobState=strtoupper((string)($jobRow['status'] ?? ''));
        if ($jobTechId==='' && $sourceTechnicianId!=='' && in_array($jobState,['ASSIGNED','IN_PROGRESS'],true)) {
            $jobTechId=$sourceTechnicianId;
            $jobTechName=$sourceTechnicianName ?: 'Assigned Technician';
            $jobRow['technician_assignment_source']='SERVICE_REQUEST';
        }
        $jobRow['technician_id']=$jobTechId;
        $jobRow['technician_name']=$jobTechName;
        $jobRow['technicianId']=$jobTechId;
        $jobRow['technicianName']=$jobTechName;
        $jobRow['temporary_override']=$jobTechId!=='' && !empty($jobRow['technician_home_customer_id'])
            && (string)$jobRow['technician_home_customer_id'] !== (string)$jobRow['customer_id'];
        $jobRow['has_signed_copy']=!empty($jobRow['signed_copy_data']);
        unset($jobRow['signed_copy_data'],$jobRow['technician_account_name']);
    }
    unset($jobRow);
    json_out(['case'=>bw_case_view($case),'events'=>$events->fetchAll(),'spares'=>$spares->fetchAll(),'jobCards'=>$jobRows]);
}

if ($method === 'GET' && $action === 'sync') {
    if (bw_is_technician_actor($ctx)) json_error('Maintenance source synchronization is restricted to Workshop/Administration.',403);
    $scopeCustomer = in_array($ctx['kind'], ['customer','customer-tech'], true) ? $ctx['customerId'] : null;
    if ($ctx['kind']==='belm' && !empty($ctx['isTechnician'])) {
        if ($ctx['customerId']==='') json_out(['ok'=>true,'sync'=>['created'=>0,'serviceRequests'=>0,'operatorReports'=>0]]);
        $scopeCustomer = $ctx['customerId'];
    }
    $sync = belm_sync_breakdown_sources($scopeCustomer ?: null);
    json_out(['ok'=>true,'sync'=>$sync]);
}

if ($method === 'GET' && $action === 'from-report') {
    if (bw_is_technician_actor($ctx)) json_error('Technicians use assigned Job Cards; report-to-case management is restricted.',403);
    $reportId=trim((string)($_GET['reportId'] ?? '')); if($reportId==='') json_error('reportId is required.');
    $caseId=bw_ensure_case_from_report($reportId,$ctx); if(!$caseId) json_error('Report not found.',404);
    $case=bw_case_access($ctx,$caseId); json_out(['case'=>bw_case_view($case)]);
}

if ($method === 'GET' && $action === '') {
    if (bw_is_technician_actor($ctx)) json_error('Technicians use My Job Cards; full Maintenance Process list is restricted.',403);
    $params=[]; $where=['1=1'];
    if($ctx['kind']==='customer'){
        $where[]='bc.customer_id=?'; $params[]=$ctx['customerId'];
    } elseif($ctx['kind']==='customer-tech'){
        $where[]='bc.customer_id=?'; $params[]=$ctx['customerId'];
        $where[]='c.is_machinery_admin=1';
    } else {
        if(!empty($ctx['isTechnician'])) {
            // BELM technicians see provider-ON work for their home customer,
            // explicit Job Card overrides, or an official support request
            // assigned to them even when the customer runs its own workshop.
            if($ctx['customerId']!=='') {
                $where[]='((c.is_machinery_admin=0 AND bc.customer_id=?) OR EXISTS (SELECT 1 FROM digital_job_cards tj WHERE tj.case_id=bc.id AND tj.technician_id=?) OR (bc.source_type=\'SERVICE_REQUEST\' AND EXISTS (SELECT 1 FROM service_requests sr WHERE sr.id=bc.source_id AND sr.assigned_to_id=?)))';
                $params[]=$ctx['customerId'];
                $params[]=$ctx['actorId'];
                $params[]=$ctx['actorId'];
            } else {
                $where[]='(EXISTS (SELECT 1 FROM digital_job_cards tj WHERE tj.case_id=bc.id AND tj.technician_id=?) OR (bc.source_type=\'SERVICE_REQUEST\' AND EXISTS (SELECT 1 FROM service_requests sr WHERE sr.id=bc.source_id AND sr.assigned_to_id=?)))';
                $params[]=$ctx['actorId'];
                $params[]=$ctx['actorId'];
            }
        } else {
            // BELM Admin/Workshop Manager normally sees provider-ON customers.
            // Exception: an official BELM Support Request is intentionally
            // visible even when the customer uses its own maintenance team.
            $where[]='(c.is_machinery_admin=0 OR bc.source_type=\'SERVICE_REQUEST\')';
        }
    }
    $machineId=trim((string)($_GET['machineId'] ?? '')); if($machineId!==''){ $where[]='bc.machine_id=?'; $params[]=$machineId; }
    $where[]="bc.status <> 'COMPLETED'";
    $stmt=db()->prepare('SELECT bc.*,c.name customer_name,c.is_machinery_admin,m.brand,m.model,m.machine_type,m.serial_number,m.reg_number,m.fleet_number FROM breakdown_cases bc JOIN customers c ON c.id=bc.customer_id JOIN machines m ON m.id=bc.machine_id WHERE '.implode(' AND ',$where).' ORDER BY bc.opened_at DESC, bc.updated_at DESC');
    $stmt->execute($params); $out=[]; foreach($stmt->fetchAll() as $r)$out[]=bw_case_view($r); json_out($out);
}

// Phase 31: read-only manager review inbox; scoped to the authenticated customer.
if ($method === 'GET' && $action === 'abnormal-checkups') {
    if ($ctx['kind'] !== 'customer' || (!$ctx['isOwner'] && !in_array($ctx['role'], ['workshop_manager','admin'], true))) {
        json_error('Only Customer Admin or Workshop Manager can review abnormal Check Ups.', 403);
    }
    $stmt = db()->prepare("SELECT cr.id,cr.machine_id,cr.overall_status,cr.filled_by,cr.created_at,
                                  m.brand,m.model,m.fleet_number,
                                  (SELECT bc.id FROM breakdown_cases bc WHERE bc.machine_id=m.id AND bc.customer_id=m.customer_id
                                     AND bc.status NOT IN ('COMPLETED','CANCELLED') ORDER BY bc.opened_at DESC LIMIT 1) AS open_case_id
                           FROM checklist_reports cr JOIN machines m ON m.id=cr.machine_id
                           JOIN customers c ON c.id=m.customer_id
                           WHERE m.customer_id=? AND m.deleted_at IS NULL AND c.deleted_at IS NULL
                             AND c.is_machinery_admin=1 AND UPPER(cr.overall_status) IN ('YELLOW','RED')
                           ORDER BY cr.created_at DESC LIMIT 50");
    $stmt->execute([$ctx['customerId']]);
    json_out(['items'=>$stmt->fetchAll()]);
}

// Phase 30: Manager-reviewed escalation from an abnormal daily machine checkup.
// Reuses an existing open case instead of creating a second Job Card for the same machine.
if ($method === 'POST' && $action === 'case-from-checkup') {
    if ($ctx['kind'] !== 'customer' || (!$ctx['isOwner'] && !in_array($ctx['role'], ['workshop_manager','admin'], true))) {
        json_error('Only Customer Admin or Workshop Manager can escalate a Check Up.', 403);
    }
    $b = body();
    $reportId = trim((string)($b['checkupReportId'] ?? ''));
    if ($reportId === '') json_error('Check Up report is required.', 422);
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $reportStmt = $pdo->prepare(
            "SELECT r.id,r.machine_id,r.overall_status,r.filled_by,r.created_at,m.customer_id,m.brand,m.model,c.is_machinery_admin
             FROM checklist_reports r JOIN machines m ON m.id=r.machine_id
             JOIN customers c ON c.id=m.customer_id
             WHERE r.id=? AND m.customer_id=? AND m.deleted_at IS NULL AND c.deleted_at IS NULL LIMIT 1"
        );
        $reportStmt->execute([$reportId,$ctx['customerId']]);
        $report = $reportStmt->fetch();
        if (!$report) json_error('Check Up report not found for this customer.', 404);
        if (!in_array(strtoupper((string)$report['overall_status']), ['YELLOW','RED'], true)) {
            json_error('Only YELLOW or RED Check Ups require breakdown escalation.', 409);
        }
        if (empty($report['is_machinery_admin'])) json_error('Customer internal workshop is disabled. Request official BELM support instead.', 403);
        // Serialize concurrent manager actions on the same machine.
        $lock = $pdo->prepare('SELECT id FROM machines WHERE id=? AND customer_id=? FOR UPDATE');
        $lock->execute([$report['machine_id'],$ctx['customerId']]);
        if (!$lock->fetchColumn()) json_error('Machine not available.', 404);
        $existing = $pdo->prepare(
            "SELECT id FROM breakdown_cases WHERE customer_id=? AND machine_id=? AND status NOT IN ('COMPLETED','CANCELLED') ORDER BY opened_at DESC LIMIT 1"
        );
        $existing->execute([$ctx['customerId'],$report['machine_id']]);
        $caseId = (string)($existing->fetchColumn() ?: '');
        $reused = $caseId !== '';
        if (!$reused) {
            $caseId = uuid();
            $label = trim((string)$report['brand'].' '.(string)$report['model']);
            $title = 'Check Up '.strtoupper((string)$report['overall_status']).' - '.($label ?: 'Machine');
            $description = 'Manager escalated abnormal Check Up '.$reportId.' ('.strtoupper((string)$report['overall_status']).'). Report by '.$report['filled_by'].'.';
            $pdo->prepare("INSERT INTO breakdown_cases(id,customer_id,machine_id,source_type,title,description,status,current_stage,current_department,opened_at,stage_started_at,updated_at,created_by_name) VALUES(?,?,?,'BREAKDOWN_CASE',?,?,'OPEN','WORKSHOP_REVIEW','Workshop',NOW(),NOW(),NOW(),?)")
                ->execute([$caseId,$ctx['customerId'],$report['machine_id'],$title,$description,$ctx['actorName']]);
        }
        // Retried requests for this same checkup must not create duplicate history events.
        // Machine row is already locked, serializing concurrent escalations.
        $checkupEvent = $pdo->prepare(
            "SELECT 1 FROM breakdown_case_events WHERE case_id=? AND action IN ('CHECKUP LINKED TO EXISTING CASE','CHECKUP ESCALATED BY MANAGER') AND note LIKE ? LIMIT 1"
        );
        $checkupEvent->execute([$caseId, 'Check Up '.$reportId.'; severity %']);
        if (!$checkupEvent->fetchColumn()) {
            bw_log($caseId,'WORKSHOP_REVIEW','Workshop',$reused ? 'CHECKUP LINKED TO EXISTING CASE' : 'CHECKUP ESCALATED BY MANAGER','Check Up '.$reportId.'; severity '.strtoupper((string)$report['overall_status']),$ctx);
        }
        // The normal helper is idempotent at case level; no duplicate Job Card is issued.
        $job = belm_ensure_job_card_for_breakdown_case($caseId,$ctx['actorName'],true);
        $pdo->commit();
        json_out(['id'=>$caseId,'checkupReportId'=>$reportId,'reusedCase'=>$reused,'jobCardNo'=>$job['jobCardNo']??null],$reused ? 200 : 201);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

if ($method === 'POST' && $action === 'case') {
    if($ctx['kind']!=='customer') json_error('Create the case from the customer workflow or problem report.',403);
    if(!$ctx['isOwner'] && !in_array($ctx['role'],['workshop_manager','admin'],true)) json_error('Only Administration/Customer Admin or Workshop Manager can open a manual Breakdown Case. Operators should use Report Problem.',403);
    $modeStmt=db()->prepare('SELECT is_machinery_admin FROM customers WHERE id=?'); $modeStmt->execute([$ctx['customerId']]);
    if(empty($modeStmt->fetchColumn())) json_error('BELM Service is ON. Customer internal Technician workflow is locked. Use Send Job Card to BELM for this machine.',403);
    $b=body(); $machineId=trim((string)($b['machineId']??'')); $desc=trim((string)($b['description']??'')); $title=trim((string)($b['title']??'Machine Breakdown'));
    if($machineId===''||$desc==='') json_error('Machine and problem description are required.');
    $m=db()->prepare('SELECT 1 FROM machines WHERE id=? AND customer_id=? AND deleted_at IS NULL'); $m->execute([$machineId,$ctx['customerId']]); if(!$m->fetch())json_error('Machine not found.',404);
    $caseId=uuid(); db()->prepare("INSERT INTO breakdown_cases(id,customer_id,machine_id,source_type,title,description,status,current_stage,current_department,opened_at,stage_started_at,updated_at,created_by_name) VALUES(?,?,?,'BREAKDOWN_CASE',?,?,'OPEN','WORKSHOP_REVIEW','Workshop',NOW(),NOW(),NOW(),?)")->execute([$caseId,$ctx['customerId'],$machineId,$title,$desc,$ctx['actorName']]);
    bw_log($caseId,'WORKSHOP_REVIEW','Workshop','Breakdown case opened',$desc,$ctx);
    $autoJob=belm_ensure_job_card_for_breakdown_case($caseId,$ctx['actorName'],true);
    json_out(['id'=>$caseId,'jobCardNo'=>$autoJob['jobCardNo']??null],201);
}

if ($method === 'POST' && $action === 'job-card') {
    if (bw_is_technician_actor($ctx)) json_error('Technicians cannot issue or reassign Job Cards. Workshop/Administration must assign them.',403);
    $b=body(); $caseId=trim((string)($b['caseId']??'')); $case=bw_case_access($ctx,$caseId);
    $jobCardMode=strtolower(trim((string)($b['jobCardMode']??'auto')));
    if(!in_array($jobCardMode,['auto','create','existing'],true)) json_error('Invalid Job Card source.',422);
    if($ctx['kind']==='customer' && !$ctx['isOwner'] && !in_array($ctx['role'],['workshop_manager','admin'],true)) json_error('Only Customer Admin or Workshop Manager can issue or reassign an internal Customer Job Card.',403);
    if($ctx['kind']==='customer' && strtoupper((string)($case['source_type']??''))==='SERVICE_REQUEST') json_error('This is an official Job Card sent to BELM. BELM Admin / Workshop Manager assigns the BELM Technician.',403);
    if($ctx['kind']==='customer' && empty($case['is_machinery_admin'])) json_error('BELM Service is ON. Customer Technician assignment is locked. Send or follow the BELM Job Card; BELM Workshop Manager assigns the BELM Technician.',403);
    if($ctx['kind']==='customer-tech') json_error('Technicians cannot generate or assign Job Cards. Customer Admin / Workshop Manager must issue the Job Card.',403);
    if($ctx['kind']==='belm' && empty($case['is_machinery_admin'])===false) json_error('This customer uses its own maintenance team. BELM can work here only after an official Customer Admin Job Card is sent to BELM.',403);

    $techId=trim((string)($b['technicianId']??'')); $techName=null; $temporaryOverride=false; $techHomeName=null; $tech=null;
    if($techId!==''){
        $t=db()->prepare("SELECT u.name,u.email,u.assigned_customer_id,u.is_customer_managed,hc.name AS home_customer_name
                          FROM users u JOIN roles r ON r.id=u.role_id
                          LEFT JOIN customers hc ON hc.id=u.assigned_customer_id
                          WHERE u.id=? AND u.is_active=1 AND u.deleted_at IS NULL
                            AND (r.name='Technician' OR EXISTS (
                                 SELECT 1 FROM user_roles ur JOIN roles rr ON rr.id=ur.role_id
                                 WHERE ur.user_id=u.id AND rr.name='Technician' AND rr.deleted_at IS NULL
                            ))");
        $t->execute([$techId]); $tech=$t->fetch(); if(!$tech)json_error('Selected Technician is not available.');
        $techName=(string)$tech['name']; $techHomeName=$tech['home_customer_name']??null;
        $temporaryOverride=!empty($tech['assigned_customer_id']) && (string)$tech['assigned_customer_id']!==(string)$case['customer_id'];
        if($ctx['kind']==='belm') {
            if(!empty($tech['is_customer_managed'])) json_error('Customer-managed Technicians cannot be borrowed by BELM. Select a BELM Technician.',403);
            if($temporaryOverride) {
                if(empty($b['temporaryOverride'])) json_error('Selected Technician belongs to another customer. Confirm Temporary Override for this Job Card.',409);
                if(empty($ctx['canOverrideTechnician'])) json_error('Only BELM Super Admin or Workshop Manager can use a Temporary Technician Override.',403);
            }
        } else {
            if(empty($tech['is_customer_managed'])) json_error('Select one of this customer\'s own Technicians. BELM Technicians are assigned only by BELM Admin/Workshop Manager.',403);
            if($temporaryOverride || (string)$tech['assigned_customer_id']!==(string)$case['customer_id']) json_error('Selected Technician is not available for this customer.',403);
        }
        // Workload protection: do not add a new active Job Card to a Technician
        // who already has five or more active jobs. The current case is excluded
        // so confirming the same assignment does not block itself.
        $loadStmt=db()->prepare("SELECT COUNT(*) FROM digital_job_cards WHERE technician_id=? AND status NOT IN ('COMPLETED','CANCELLED') AND case_id<>?");
        $loadStmt->execute([$techId,$caseId]);
        $activeJobs=(int)$loadStmt->fetchColumn();
        if($activeJobs>=5) json_error($techName.' is FULL with '.$activeJobs.' active jobs. Complete or reassign an existing job before adding another.',409);
    }
    if($ctx['kind']==='customer' && $techId==='') json_error('Select one of your customer-managed Technicians.',422);

    $title=trim((string)($b['title']??$case['title']));
    $jobLocation=trim((string)($b['jobLocation']??''));
    if($jobLocation==='') $jobLocation=trim((string)($case['customer_address']??''));
    $initialJobStatus=$techId!==''?'ASSIGNED':'RECEIVED';
    $workshopInstruction=trim((string)($b['workshopInstruction']??''));
    if(mb_strlen($workshopInstruction)>1000) json_error('Workshop Manager instruction is too long (max 1000 characters).',422);

    // V413 - Customer Existing Job Card handover/reassignment.
    // The same card remains the official work record; diagnosis, work history,
    // parts and timeline are preserved when responsibility moves to another
    // customer-managed Technician.
    if($ctx['kind']==='customer' && $jobCardMode==='existing') {
        if(strtoupper((string)($case['source_type']??''))==='SERVICE_REQUEST') json_error('This is an official Job Card sent to BELM. Only BELM Admin/Workshop Manager can reassign its BELM Technician.',403);
        $requestedJobId=trim((string)($b['jobCardId']??''));
        if($requestedJobId==='') json_error('Select an existing Job Card.',422);
        $jobStmt=db()->prepare("SELECT id,job_card_no,title,status,technician_id,technician_name,job_location
                                FROM digital_job_cards
                                WHERE id=? AND case_id=? AND customer_id=? LIMIT 1");
        $jobStmt->execute([$requestedJobId,$caseId,$case['customer_id']]);
        $job=$jobStmt->fetch();
        if(!$job) json_error('Selected Job Card was not found for this customer case.',404);
        $currentStatus=strtoupper(trim((string)($job['status']??'')));
        if(in_array($currentStatus,['PENDING_APPROVAL','COMPLETED','CANCELLED'],true)) json_error('This Job Card can no longer be reassigned. Pending Approval must be reviewed; Completed/Cancelled cards are closed.',409);
        $previousTechnicianId=trim((string)($job['technician_id']??''));
        $previousTechnicianName=trim((string)($job['technician_name']??''));
        $reassigned=$previousTechnicianId!=='' && $previousTechnicianId!==$techId;
        $sameAssignment=$previousTechnicianId!=='' && $previousTechnicianId===$techId;
        $handoverReason=trim((string)($b['handoverReason']??''));
        if ($reassigned && $handoverReason==='') json_error('Enter the handover reason before reassigning this Job Card.',422);
        if (mb_strlen($handoverReason)>1000) json_error('Handover reason is too long (max 1000 characters).',422);
        $preservedStatus=in_array($currentStatus,['IN_PROGRESS','WAITING_FOR_PARTS'],true)?$currentStatus:'ASSIGNED';
        db()->prepare("UPDATE digital_job_cards
                       SET technician_id=?,technician_name=?,status=?,received_at=CASE WHEN technician_id IS DISTINCT FROM ? THEN NULL ELSE received_at END,started_at=CASE WHEN technician_id IS DISTINCT FROM ? THEN NULL ELSE started_at END,job_location=COALESCE(NULLIF(?,''),job_location),updated_at=NOW()
                       WHERE id=?")
            ->execute([$techId,$techName,$preservedStatus,$techId,$techId,$jobLocation,$requestedJobId]);
        $action=$reassigned
            ? 'Customer Job Card '.$job['job_card_no'].' reassigned to '.$techName
            : ($sameAssignment ? 'Customer Job Card '.$job['job_card_no'].' assignment confirmed for '.$techName : 'Customer Job Card '.$job['job_card_no'].' assigned to '.$techName);
        $note=$reassigned
            ? 'Handover from '.($previousTechnicianName?:'previous Technician').($handoverReason!==''?'. Reason: '.$handoverReason:'')
            : ($handoverReason!==''?$handoverReason:'Customer workshop assignment.');
        if(in_array($preservedStatus,['ASSIGNED','RECEIVED','OPEN'],true)) {
            bw_set_stage($caseId,'JOB_CARD_ASSIGNED',null,$ctx,$action);
            if($note!=='Customer workshop assignment.') bw_log($caseId,'JOB_CARD_ASSIGNED','Technician',$action,$note,$ctx);
        } else {
            bw_log($caseId,(string)($case['current_stage']?:'JOB_CARD_ASSIGNED'),(string)($case['current_department']?:'Technician'),$action,$note,$ctx);
        }
        if($workshopInstruction!=='') {
            bw_log($caseId,(string)($case['current_stage']?:'JOB_CARD_ASSIGNED'),'Workshop','WORKSHOP_MANAGER_INSTRUCTION',$workshopInstruction,$ctx);
        }
        // In-portal coordination survives an email outage and is scoped to the
        // workshop that owns this card, not the other company's inbox.
        try {
            $noticeScope=$ctx['kind']==='belm'?'BELM':'CUSTOMER';
            bw_role_message($ctx,$case,$noticeScope,'workshop_manager',
                'JOB CARD '.($reassigned?'REASSIGNED':'ASSIGNED').' - '.$job['job_card_no'],
                'Technician: '.$techName.'. '.($reassigned?'Previous: '.($previousTechnicianName?:'Unknown').'. ':'').
                ($handoverReason!==''?'Handover reason: '.$handoverReason.'. ':'').
                'Review the Job Card and track progress in Breakdown Workflow.',
                'NORMAL','JOB_CARD',$requestedJobId);
        } catch(Throwable $e) { error_log('Job Card coordination notice failed: '.$e->getMessage()); }
        try {
            $email=trim((string)($tech['email']??''));
            if(filter_var($email,FILTER_VALIDATE_EMAIL)) send_email($email,'DIGITAL JOB CARD '.$job['job_card_no'],
                "Job Card {$job['job_card_no']} has been ".($reassigned?'reassigned':'assigned')." to you by {$ctx['actorName']}.\n".
                ($reassigned && $previousTechnicianName!==''?"Previous Technician: $previousTechnicianName\n":'').
                ($handoverReason!==''?"Handover note: $handoverReason\n":'').
                ($workshopInstruction!==''?"Workshop Manager Instruction: $workshopInstruction\n":'').
                "Machine: ".$case['brand'].' '.$case['model'].($jobLocation!==''?"\nJob location: $jobLocation\nNavigate: https://www.google.com/maps/dir/?api=1&destination=".rawurlencode($jobLocation):'').
                "\nFault: ".$case['description']."\nOpen Technician > My Job Cards. Existing Job Card history remains available.");
        } catch(Throwable $e) {}
        // Notify the previous technician that the assignment has ended; do not
        // leave a stale active assignment in their understanding of the work.
        if ($reassigned) {
            try {
                $prior=db()->prepare('SELECT email FROM users WHERE id=? AND is_active=1 AND deleted_at IS NULL LIMIT 1');
                $prior->execute([$previousTechnicianId]);
                $priorEmail=trim((string)$prior->fetchColumn());
                if (filter_var($priorEmail,FILTER_VALIDATE_EMAIL)) {
                    send_email($priorEmail,'JOB CARD '.$job['job_card_no'].' - REASSIGNED',
                        'You are no longer assigned to Job Card '.$job['job_card_no'].'.'."\n".
                        'New technician: '.$techName."\n".'Handover reason: '.$handoverReason."\n".
                        'The existing Job Card history is preserved. Contact your Workshop Manager if clarification is needed.');
                }
            } catch(Throwable $e) { /* Never roll back a valid handover for an email provider outage. */ }
        }
        json_out(['id'=>$requestedJobId,'jobCardNo'=>$job['job_card_no'],'mode'=>'existing','reassigned'=>$reassigned,'previousTechnicianName'=>$previousTechnicianName?:null,'status'=>$preservedStatus],200);
    }

    // Create/legacy auto mode: one active Job Card per maintenance case.
    $existingJob = db()->prepare(
        "SELECT id, job_card_no, status, technician_id FROM digital_job_cards
         WHERE case_id = ? AND status NOT IN ('COMPLETED','CANCELLED')
         ORDER BY created_at ASC LIMIT 1"
    );
    $existingJob->execute([$caseId]);
    $existingJobRow = $existingJob->fetch();
    $createdNew=false;
    if ($existingJobRow) {
        if($jobCardMode==='create') json_error('An active Job Card already exists for this case. Select Existing Job Card to assign/reassign it instead of creating a duplicate.',409);
        if (!empty($existingJobRow['technician_id'] ?? null) || in_array(strtoupper((string)$existingJobRow['status']), ['ASSIGNED', 'IN_PROGRESS', 'WAITING_FOR_PARTS', 'PENDING_APPROVAL'], true)) {
            json_error('Job Card '.$existingJobRow['job_card_no'].' already exists for this case and is already assigned. Select Existing Job Card / handover instead of generating a new one.', 409);
        }
        $jobId = (string)$existingJobRow['id'];
        $num = (string)$existingJobRow['job_card_no'];
        db()->prepare(
            "UPDATE digital_job_cards
             SET technician_id=?,technician_name=?,status=?,job_location=COALESCE(NULLIF(?,''),job_location),updated_at=NOW()
             WHERE id=?"
        )->execute([$techId?:null,$techName?:null,$initialJobStatus,$jobLocation,$jobId]);
    } else {
        $num=belm_next_job_card_number();
        $jobId=uuid(); $createdNew=true;
        db()->prepare("INSERT INTO digital_job_cards(id,case_id,customer_id,machine_id,job_card_no,title,fault_description,technician_id,technician_name,status,job_location,generated_by_name,issued_by_name,issued_by_type,issued_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())")->execute([$jobId,$caseId,$case['customer_id'],$case['machine_id'],$num,$title,$case['description'],$techId?:null,$techName?:null,$initialJobStatus,$jobLocation?:null,$ctx['actorName'],$ctx['actorName'],strtoupper((string)$ctx['kind']),date('c')]);
    }
    if ($ctx['kind']==='customer' && $createdNew) {
        bw_log($caseId,'TECHNICIAN_ASSIGNMENT','Workshop','Digital Job Card '.$num.' created','Internal Customer Job Card - remains inside the customer workshop team.',$ctx);
    }
    if ($techId !== '') {
        bw_set_stage($caseId,'JOB_CARD_ASSIGNED',null,$ctx,'Digital Job Card '.$num.($createdNew?' created and assigned':' assigned'));
    } else {
        bw_set_stage($caseId,'TECHNICIAN_ASSIGNMENT','Awaiting Technician Assignment',$ctx,'Digital Job Card '.$num.' generated - waiting Technician assignment');
    }
    if($workshopInstruction!=='') {
        bw_log($caseId,$techId!==''?'JOB_CARD_ASSIGNED':'TECHNICIAN_ASSIGNMENT','Workshop','WORKSHOP_MANAGER_INSTRUCTION',$workshopInstruction,$ctx);
    }
    if ($temporaryOverride && $techId!=='') {
        bw_log($caseId,'JOB_CARD_ASSIGNED','Technician','Temporary Technician Override - '.$techName,
            'Home customer: '.($techHomeName ?: 'Unassigned').'. Override applies only to Job Card '.$num.'.', $ctx);
    }
    if ($techId!=='') {
        // Managers can verify dispatch inside the portal even if SMTP is unset.
        try {
            $noticeScope=$ctx['kind']==='belm'?'BELM':'CUSTOMER';
            bw_role_message($ctx,$case,$noticeScope,'workshop_manager',
                'JOB CARD ASSIGNED - '.$num,
                'Technician: '.$techName.'. Job Card '.$num.' is assigned. '.
                ($temporaryOverride?'Temporary customer override is active. ':'').
                'Follow progress in Breakdown Workflow.',
                'NORMAL','JOB_CARD',$jobId);
        } catch(Throwable $e) { error_log('Job Card assignment notice failed: '.$e->getMessage()); }
        try { $email=trim((string)($tech['email']??'')); if(filter_var($email,FILTER_VALIDATE_EMAIL)) send_email($email,'DIGITAL JOB CARD '.$num,"Job Card $num has been assigned to you.".($temporaryOverride?"\nAssignment: TEMPORARY OVERRIDE (your permanent customer has not changed).":'')."\nMachine: ".$case['brand'].' '.$case['model'].($jobLocation!==''?"\nJob location: $jobLocation\nNavigate: https://www.google.com/maps/dir/?api=1&destination=".rawurlencode($jobLocation):'')."\nFault: ".$case['description'].($workshopInstruction!==''?"\nWorkshop Manager Instruction: $workshopInstruction":'')."\nOpen Technician > My Job Cards."); } catch(Throwable $e) {}
    }
    json_out(['id'=>$jobId,'jobCardNo'=>$num,'mode'=>$jobCardMode==='auto'?'create':$jobCardMode,'reassigned'=>false],201);
}

if ($method === 'POST' && $action === 'spare') {
    $b=body(); $caseId=trim((string)($b['caseId']??'')); $case=bw_case_access($ctx,$caseId);
    $jobCardId=trim((string)($b['jobCardId']??''));
    if (bw_is_technician_actor($ctx) && $jobCardId==='') json_error('A Technician spare request must come from an assigned Job Card.',403);
    if ($jobCardId!=='') {
        $jobCheck=db()->prepare('SELECT id,case_id,technician_id FROM digital_job_cards WHERE id=?');
        $jobCheck->execute([$jobCardId]); $jobForSpare=$jobCheck->fetch();
        if(!$jobForSpare || (string)$jobForSpare['case_id']!==$caseId) json_error('The selected Job Card does not belong to this maintenance case.',422);
        bw_require_assigned_job($ctx,$jobForSpare);
    }
    $name=trim((string)($b['spareName']??'')); $qty=(float)($b['quantity']??1); if($name===''||$qty<=0)json_error('Spare name and quantity are required.');
    $spareId=uuid(); db()->prepare("INSERT INTO breakdown_spare_requests(id,case_id,job_card_id,spare_name,part_number,quantity,unit,reason,status,requested_by_name,requested_at,updated_at) VALUES(?,?,?,?,?,?,?,?, 'WAITING_BOSS_APPROVAL',?,NOW(),NOW())")->execute([$spareId,$caseId,$jobCardId!==''?$jobCardId:null,$name,trim((string)($b['partNumber']??''))?:null,$qty,trim((string)($b['unit']??'pcs'))?:'pcs',trim((string)($b['reason']??''))?:null,$ctx['actorName']]);
    bw_set_stage($caseId,'BOSS_APPROVAL','Waiting for Administration approval of spare request',$ctx,'Spare requested - waiting Administration approval');
    // An internal Customer Workshop request belongs to Customer Administration;
    // an official BELM support job belongs to BELM Administration.
    $approvalScope = !empty($case['is_machinery_admin']) && strtoupper((string)($case['source_type'] ?? '')) !== 'SERVICE_REQUEST' ? 'CUSTOMER' : 'BELM';
    $approvalRole = $approvalScope === 'BELM' ? 'super_admin' : 'customer_admin';
    bw_role_message($ctx,$case,$approvalScope,$approvalRole,'SPARE APPROVAL REQUIRED - '.$case['model'],
        'Spare '.$name.' x '.$qty.' requires Administration approval before Store / Procurement continues.','ATTENTION','spare_request',$spareId);
    if ($approvalScope === 'CUSTOMER') {
        try {
            $owner = db()->prepare('SELECT email FROM customers WHERE id=? AND is_active=1 AND deleted_at IS NULL');
            $owner->execute([(string)$case['customer_id']]);
            $ownerEmail = trim((string)$owner->fetchColumn());
            if (filter_var($ownerEmail, FILTER_VALIDATE_EMAIL)) {
                send_email($ownerEmail, 'SPARE APPROVAL REQUIRED - '.$case['model'],
                    "Administration approval required\nMachine: ".$case['brand'].' '.$case['model']."\nSpare: $name\nQty: $qty\nRequested by: ".$ctx['actorName']."\nOpen Breakdown Workflow to approve or reject.");
            }
        } catch(Throwable $e) {}
    }
    json_out(['id'=>$spareId],201);
}

if ($method === 'PUT' && $action === 'approve-spare' && $id !== '') {
    $stmt=db()->prepare('SELECT bsr.*,bc.customer_id FROM breakdown_spare_requests bsr JOIN breakdown_cases bc ON bc.id=bsr.case_id WHERE bsr.id=?');
    $stmt->execute([$id]); $s=$stmt->fetch();
    if (!$s) json_error('Spare request not found.',404);
    $case=bw_case_access($ctx,(string)$s['case_id']);
    $customerApproval=$ctx['kind']==='customer' && !empty($ctx['isOwner']);
    $belmApproval=$ctx['kind']==='belm' && in_array($ctx['role'],['super admin'],true);
    if (!$customerApproval && !$belmApproval) json_error('Administration approval is required for this spare request.',403);
    // Customer-owned jobs must not be approved by BELM, nor vice versa.
    $customerOwned=!empty($case['is_machinery_admin']) && strtoupper((string)($case['source_type']??''))!=='SERVICE_REQUEST';
    if ($customerOwned && !$customerApproval) json_error('Customer Administration approval required.',403);
    if (!$customerOwned && !$belmApproval) json_error('BELM Administration approval required.',403);
    if (strtoupper((string)($s['status']??''))!=='WAITING_BOSS_APPROVAL') json_error('Spare request is not awaiting Administration approval.',409);
    $notificationScope=$customerOwned?'CUSTOMER':'BELM';
    $b=body(); $approve=!empty($b['approve']); $status=$approve?'APPROVED':'REJECTED';
    db()->prepare('UPDATE breakdown_spare_requests SET status=?,approved_by_name=?,approved_at=NOW(),approval_note=?,updated_at=NOW() WHERE id=?')->execute([$status,$ctx['actorName'],trim((string)($b['note']??''))?:null,$id]);
    bw_set_stage($s['case_id'],$approve?'STORE_CHECK':'DIAGNOSIS',$approve?null:'Spare rejected by Administration',$ctx,$approve?'Spare approved by Administration':'Spare rejected by Administration');
    if ($approve) {
        bw_role_message($ctx,$case,$notificationScope,'store_keeper','SPARE APPROVED - STORE ACTION REQUIRED',
            "Administration approved {$s['spare_name']} x {$s['quantity']}. Check Customer Store; if unavailable route the shortage to Procurement.",'ATTENTION','spare_request',$id);
        try { if ($customerOwned) customer_send_team_alert($ctx['customerId'],['store'],'SPARE APPROVED - STORE ACTION REQUIRED',"Administration approved spare: {$s['spare_name']} x {$s['quantity']}. Check Customer Store; if unavailable send to Procurement.",false); } catch(Throwable $e) {}
    } else {
        bw_role_message($ctx,$case,$notificationScope,'workshop_manager','SPARE REQUEST REJECTED',
            "Administration rejected {$s['spare_name']} x {$s['quantity']}. Review the diagnosis / Job Card before continuing.",'ATTENTION','spare_request',$id);
    }
    json_out(['ok'=>true,'status'=>$status]);
}

if ($method === 'PUT' && $action === 'spare-status' && $id !== '') {
    if (bw_is_technician_actor($ctx)) json_error('Technicians request spares from Job Cards; Store/Procurement status is managed by authorized departments.',403);
    // Department-specific authorization is enforced on the API, not only the dashboard.
    // Do not allow generic page access to change financial/procurement milestones.

    $stmt=db()->prepare('SELECT bsr.*,bc.customer_id FROM breakdown_spare_requests bsr JOIN breakdown_cases bc ON bc.id=bsr.case_id WHERE bsr.id=?'); $stmt->execute([$id]); $s=$stmt->fetch(); if(!$s)json_error('Spare request not found.',404); $case=bw_case_access($ctx,(string)$s['case_id']);
    $b=body(); $status=strtoupper(trim((string)($b['status']??''))); $allowed=['STORE_AVAILABLE','PROCUREMENT_REQUIRED','PI_WAITING_ACCOUNTS','ORDERED','PARTS_READY']; if(!in_array($status,$allowed,true))json_error('Invalid spare process status.');
    if ($ctx['kind']==='customer' && !$ctx['isOwner']) {
        $role=$ctx['role'];
        if (in_array($status,['STORE_AVAILABLE','PROCUREMENT_REQUIRED','PARTS_READY'],true) && !in_array($role,['store_keeper','workshop_manager','admin'],true)) json_error('Store Keeper or Workshop Manager action required.',403);
        if (in_array($status,['PI_WAITING_ACCOUNTS','ORDERED'],true) && !in_array($role,['procurement','accounts','admin'],true)) json_error('Procurement or Accounts action required.',403);
    }
    if ($ctx['kind'] === 'belm') {
        $role = strtolower(trim((string)($ctx['role'] ?? '')));
        $isAdmin = $role === 'super admin';
        $storeStatuses = ['STORE_AVAILABLE', 'PROCUREMENT_REQUIRED', 'PARTS_READY'];
        $financeStatuses = ['PI_WAITING_ACCOUNTS', 'ORDERED'];
        $storeRoles = ['store keeper', 'workshop manager'];
        $financeRoles = ['procurement', 'accounts', 'finance / accounts'];
        if (!$isAdmin && in_array($status, $storeStatuses, true) && !in_array($role, $storeRoles, true)) {
            json_error('BELM Store Keeper or Workshop Manager permission required for this spare status.', 403);
        }
        if (!$isAdmin && in_array($status, $financeStatuses, true) && !in_array($role, $financeRoles, true)) {
            json_error('BELM Procurement or Accounts permission required for this spare status.', 403);
        }
    }
    // Disallow either company from changing the other company's spare workflow.
    $customerOwned = !empty($case['is_machinery_admin']) && strtoupper((string)($case['source_type'] ?? '')) !== 'SERVICE_REQUEST';
    if ($customerOwned && $ctx['kind'] !== 'customer') json_error('Customer workshop controls this spare workflow.', 403);
    if (!$customerOwned && $ctx['kind'] !== 'belm') json_error('BELM controls this spare workflow.', 403);
    // Coordination follows the owner of this repair workflow, never a hardcoded CUSTOMER inbox.
    $spareNoticeScope = ($ctx['kind'] === 'customer') ? 'CUSTOMER' : 'BELM';
    $stage=match($status){'STORE_AVAILABLE'=>'PARTS_READY','PARTS_READY'=>'REPAIR','PROCUREMENT_REQUIRED','ORDERED'=>'PROCUREMENT','PI_WAITING_ACCOUNTS'=>'ACCOUNTS',default=>'STORE_CHECK'};
    db()->prepare("UPDATE breakdown_spare_requests SET status=?,fulfilled_by_name=CASE WHEN ?='PARTS_READY' THEN ? ELSE fulfilled_by_name END,fulfilled_at=CASE WHEN ?='PARTS_READY' THEN NOW() ELSE fulfilled_at END,updated_at=NOW() WHERE id=?")->execute([$status,$status,$ctx['actorName'],$status,$id]);
    if($status==='PARTS_READY' && !empty($s['job_card_id'])) {
        db()->prepare("UPDATE digital_job_cards SET status='IN_PROGRESS',updated_at=NOW() WHERE id=? AND status='WAITING_FOR_PARTS'")->execute([(string)$s['job_card_id']]);
    }
    bw_set_stage($s['case_id'],$stage,trim((string)($b['note']??''))?:null,$ctx,$status==='PARTS_READY'?'Parts ready - Technician can continue repair':'Spare process: '.$status);
    if ($status==='PROCUREMENT_REQUIRED') bw_role_message($ctx,$case,$spareNoticeScope,'procurement','PROCUREMENT ACTION REQUIRED',
        "Approved spare {$s['spare_name']} x {$s['quantity']} is not available in Store. Procurement action is required.",'ATTENTION','spare_request',$id);
    if ($status==='PI_WAITING_ACCOUNTS') bw_role_message($ctx,$case,$spareNoticeScope,'accounts','ACCOUNTS / PI ACTION REQUIRED',
        "Procurement has routed {$s['spare_name']} x {$s['quantity']} to Accounts for PI / finance action.",'ATTENTION','spare_request',$id);
    if ($status==='PARTS_READY') bw_role_message($ctx,$case,$spareNoticeScope,'workshop_manager','PARTS READY - REPAIR CAN CONTINUE',
        "Required spare {$s['spare_name']} x {$s['quantity']} is ready. Workshop can return the Job Card to repair / testing.",'ATTENTION','spare_request',$id);
    try {
        if ($ctx['kind']==='customer' && $status==='PROCUREMENT_REQUIRED') customer_send_team_alert((string)$s['customer_id'],['service-request','store'],'PROCUREMENT ACTION REQUIRED','Approved spare is not available in Store. Procurement action is required. Open Breakdown Workflow.',true);
        if ($ctx['kind']==='customer' && $status==='PI_WAITING_ACCOUNTS') customer_send_team_alert((string)$s['customer_id'],['email'],'ACCOUNTS / PI ACTION REQUIRED','Procurement has sent a breakdown spare requirement to Accounts. Open Breakdown Workflow.',true);
        if ($ctx['kind']==='customer' && $status==='PARTS_READY') customer_send_team_alert((string)$s['customer_id'],['workflow'],'PARTS READY - REPAIR CAN CONTINUE','Required spare is ready. Workshop / Technician can continue repair.',true);
    } catch(Throwable $e) {}
    json_out(['ok'=>true]);
}


// V_COORDINATOR_ROLE_FLOW: Technician receives an assigned Job Card; Technician never assigns it.
if ($method === 'PUT' && $action === 'job-receive' && $id !== '') {
    $stmt=db()->prepare('SELECT jc.*,bc.current_stage,bc.status AS case_status FROM digital_job_cards jc JOIN breakdown_cases bc ON bc.id=jc.case_id WHERE jc.id=?');
    $stmt->execute([$id]);
    $job=$stmt->fetch();
    if(!$job) json_error('Job Card not found.',404);
    bw_case_access($ctx,(string)$job['case_id']);
    if(!bw_is_technician_actor($ctx)) json_error('Only the assigned Technician can receive this Job Card.',403);
    bw_require_assigned_job($ctx,$job);
    $status=strtoupper(trim((string)($job['status']??'')));
    if(!in_array($status,['OPEN','ASSIGNED','CREATED','RECEIVED','IN_PROGRESS','WAITING_FOR_PARTS'],true)) json_error('This Job Card cannot be received in its current status.',409);
    // Atomic and idempotent acknowledgement: duplicate clicks never create another event.
    // Only the currently assigned technician can reach this action (checked above).
    $ack=db()->prepare("UPDATE digital_job_cards SET received_at=NOW(),status=CASE WHEN UPPER(status) IN ('OPEN','ASSIGNED','CREATED') THEN 'RECEIVED' ELSE status END,updated_at=NOW() WHERE id=? AND received_at IS NULL AND UPPER(COALESCE(status,'')) IN ('OPEN','ASSIGNED','CREATED','RECEIVED','IN_PROGRESS','WAITING_FOR_PARTS') RETURNING received_at,status");
    $ack->execute([$id]);
    $accepted=$ack->fetch();
    if($accepted){
        bw_log((string)$job['case_id'],'JOB_CARD_ASSIGNED','Technician','JOB_CARD_RECEIVED','Assigned Technician explicitly accepted Job Card', $ctx);
    }
    $current=db()->prepare('SELECT received_at,status FROM digital_job_cards WHERE id=?');
    $current->execute([$id]); $state=$current->fetch();
    if(empty($state['received_at'])) json_error('Job Card cannot be received in its current state.',409);
    json_out(['ok'=>true,'firstReceive'=>(bool)$accepted,'receivedAt'=>$state['received_at'],'status'=>$state['status'],'process'=>'RECEIVED']);
}

// V403 - opening the assigned Job Card is a real process event.
// This is idempotent: repeat opens never create duplicate history events.
if ($method === 'PUT' && $action === 'job-open' && $id !== '') {
    $stmt=db()->prepare('SELECT jc.*,bc.current_stage,bc.status AS case_status FROM digital_job_cards jc JOIN breakdown_cases bc ON bc.id=jc.case_id WHERE jc.id=?');
    $stmt->execute([$id]);
    $job=$stmt->fetch();
    if(!$job) json_error('Job Card not found.',404);
    bw_case_access($ctx,(string)$job['case_id']);
    if(!bw_is_technician_actor($ctx)) json_error('Only the assigned Technician can open this Job Card.',403);
    bw_require_assigned_job($ctx,$job);
    if(empty($job['received_at'])) json_error('Receive / acknowledge the Job Card before starting diagnosis.',409);
    $firstOpen=empty($job['started_at']);
    if($firstOpen){
        db()->prepare("UPDATE digital_job_cards SET started_at=COALESCE(started_at,NOW()),status=CASE WHEN UPPER(COALESCE(status,'')) IN ('RECEIVED','IN_PROGRESS') THEN 'IN_PROGRESS' ELSE status END,updated_at=NOW() WHERE id=?")
            ->execute([$id]);
        $stage=strtoupper(trim((string)($job['current_stage']??'')));
        if(in_array($stage,['JOB_CARD_ASSIGNED','TECHNICIAN_ASSIGNMENT','WORKSHOP_REVIEW'],true)){
            bw_set_stage((string)$job['case_id'],'DIAGNOSIS',null,$ctx,'Technician opened Job Card');
        }else{
            bw_log((string)$job['case_id'],$stage?:'DIAGNOSIS','Technician','Technician opened Job Card',null,$ctx);
        }
    }
    json_out(['ok'=>true,'firstOpen'=>$firstOpen,'process'=>'DIAGNOSIS']);
}

if ($method === 'PUT' && $action === 'job-report' && $id !== '') {
    $stmt=db()->prepare('SELECT jc.* FROM digital_job_cards jc JOIN breakdown_cases bc ON bc.id=jc.case_id WHERE jc.id=?'); $stmt->execute([$id]); $job=$stmt->fetch(); if(!$job)json_error('Job Card not found.',404); $case=bw_case_access($ctx,$job['case_id']);
    if($ctx['kind']==='customer' && $ctx['role']!=='technician') json_error('Technician report must be saved from a Technician login.',403);
    $isTechActor=!empty($ctx['isTechnician']) || ($ctx['kind']==='customer' && $ctx['role']==='technician');
    if(!$isTechActor) json_error('Only a Technician can save the technical Job Card report.',403);
    bw_require_assigned_job($ctx,$job);
    if(empty($job['received_at'])) json_error('Receive / acknowledge this Job Card before submitting diagnosis.',409);
    $currentJobStatus=strtoupper(trim((string)($job['status']??'')));
    if(in_array($currentJobStatus,['PENDING_APPROVAL','COMPLETED','CANCELLED'],true)) {
        json_error($currentJobStatus==='PENDING_APPROVAL'?'This Job Card has already been submitted for approval. It can be edited again only if the reviewer returns it to the Technician.':'This Job Card is already closed.',409);
    }
    $b=body(); $complete=!empty($b['complete']);
    $diagnosis=trim((string)($b['diagnosis']??''));
    $work=trim((string)($b['workDone']??''));
    $requiredSpare=trim((string)($b['requiredSpare']??''));
    $requiredSpareQty=(float)($b['requiredSpareQty']??1);
    if($requiredSpare!=='' && $requiredSpareQty<=0) json_error('Required Spare quantity must be greater than zero.');
    if($diagnosis==='') json_error('Diagnosis is required.');
    if($complete && $work==='') json_error('Work done is required before submitting the Job Card for approval.');
    $activeSpareStmt=db()->prepare("SELECT COUNT(*) AS total,string_agg(spare_name, ', ' ORDER BY requested_at) AS names FROM breakdown_spare_requests WHERE job_card_id=? AND UPPER(COALESCE(status,'')) NOT IN ('REJECTED','PARTS_READY')");
    $activeSpareStmt->execute([$id]);
    $activeSpareRow=$activeSpareStmt->fetch()?:['total'=>0,'names'=>''];
    $activeSpareCount=(int)($activeSpareRow['total']??0);
    $activeSpareNames=trim((string)($activeSpareRow['names']??''));
    if($complete && ($requiredSpare!=='' || $activeSpareCount>0)) json_error('A Job Card with a Required Spare must wait until the parts are ready before it can be submitted for approval.',409);
    $repeatProvided=array_key_exists('repeatIssue',$b);
    $repeat=!empty($b['repeatIssue']);
    if ($complete && !$repeatProvided) {
        $rp=db()->prepare("SELECT 1 FROM digital_job_cards WHERE id<>? AND machine_id=? AND status='COMPLETED' AND LOWER(TRIM(title))=LOWER(TRIM(?)) AND completed_at >= NOW()-INTERVAL '30 days' LIMIT 1");
        $rp->execute([$id,$job['machine_id'],$job['title']]);
        $repeat=(bool)$rp->fetchColumn();
    }
    $nextJobStatus=$complete?'PENDING_APPROVAL':(($requiredSpare!==''||$activeSpareCount>0)?'WAITING_FOR_PARTS':'IN_PROGRESS');
    db()->prepare("UPDATE digital_job_cards SET technician_id=?,technician_name=?,diagnosis=?,work_done=?,test_result=?,completion_note=?,repeat_issue=?,status=?,started_at=COALESCE(started_at,NOW()),technician_submitted_at=CASE WHEN ? THEN NOW() ELSE technician_submitted_at END,completed_at=NULL,reviewed_at=CASE WHEN ? THEN NULL ELSE reviewed_at END,reviewed_by_name=CASE WHEN ? THEN NULL ELSE reviewed_by_name END,review_note=CASE WHEN ? THEN NULL ELSE review_note END,updated_at=NOW() WHERE id=?")
        ->execute([$ctx['actorId'],$ctx['actorName'],$diagnosis,$work?:null,trim((string)($b['testResult']??''))?:null,trim((string)($b['completionNote']??''))?:null,$repeat?1:0,$nextJobStatus,$complete?1:0,$complete?1:0,$complete?1:0,$complete?1:0,$id]);
    $spareCreated=false;
    if($requiredSpare!==''){
        $existingSpare=db()->prepare("SELECT id FROM breakdown_spare_requests WHERE job_card_id=? AND LOWER(TRIM(spare_name))=LOWER(TRIM(?)) AND UPPER(COALESCE(status,'')) NOT IN ('REJECTED','PARTS_READY') LIMIT 1");
        $existingSpare->execute([$id,$requiredSpare]);
        if(!$existingSpare->fetchColumn()){
            db()->prepare("INSERT INTO breakdown_spare_requests(id,case_id,job_card_id,spare_name,quantity,unit,reason,status,requested_by_name,requested_at,updated_at) VALUES(?,?,?,?,?,'pcs','Required from Technician Diagnosis Report','WAITING_BOSS_APPROVAL',?,NOW(),NOW())")
                ->execute([uuid(),$job['case_id'],$id,$requiredSpare,$requiredSpareQty,$ctx['actorName']]);
            $spareCreated=true;
            try{
                $owner=db()->prepare('SELECT email FROM customers WHERE id=? AND is_active=1 AND deleted_at IS NULL');
                $owner->execute([(string)$job['customer_id']]);
                $ownerEmail=trim((string)$owner->fetchColumn());
                if(filter_var($ownerEmail,FILTER_VALIDATE_EMAIL)) send_email($ownerEmail,'SPARE APPROVAL REQUIRED - JOB CARD '.$job['job_card_no'],"Required spare from Technician Diagnosis Report
Job Card: {$job['job_card_no']}
Spare: $requiredSpare x $requiredSpareQty
Technician: {$ctx['actorName']}
Open Breakdown Workflow to approve or reject.");
            }catch(Throwable $e){}
        }
        bw_set_stage($job['case_id'],'BOSS_APPROVAL','Required spare: '.$requiredSpare,$ctx,'Diagnosis saved - waiting required spare');
    }elseif($activeSpareCount>0){
        bw_set_stage($job['case_id'],'BOSS_APPROVAL','Required spare: '.($activeSpareNames?:'Waiting for spare'),$ctx,'Diagnosis updated - required spare still waiting');
    }else{
        bw_set_stage($job['case_id'],$complete?'PENDING_APPROVAL':'REPAIR',null,$ctx,$complete?'Technician submitted completed work - waiting approval':'Technician Diagnosis Report saved');
    }
    if (($case['source_type'] ?? '') === 'SERVICE_REQUEST' && !empty($case['source_id'])) {
        // Technician work means the support request is operationally in progress.
        // Completion remains a reviewer decision after Technician submission; do not close it here.
        $srState=db()->prepare('SELECT status FROM service_requests WHERE id=?');
        $srState->execute([(string)$case['source_id']]);
        $oldSrStatus=strtoupper((string)($srState->fetchColumn() ?: ''));
        if (in_array($oldSrStatus,['OPEN','ASSIGNED'],true)) {
            db()->prepare("UPDATE service_requests SET status='IN_PROGRESS',started_by_id=COALESCE(started_by_id,?),started_at=COALESCE(started_at,NOW()),updated_at=NOW() WHERE id=?")
                ->execute([$ctx['kind']==='belm' ? ($ctx['actorId']??null) : null,(string)$case['source_id']]);
            db()->prepare('INSERT INTO service_request_history(id,request_id,event_type,from_value,to_value,actor_id,actor_name,note,created_at) VALUES(?,?,?,?,?,?,?,?,NOW())')
                ->execute([uuid(),(string)$case['source_id'],'STATUS',$oldSrStatus,'IN_PROGRESS',$ctx['kind']==='belm'?($ctx['actorId']??null):null,$ctx['actorName'],'Synchronized from Technician Job Card '.$job['job_card_no']]);
        }
    }
    // V324: Technician Job Report delivery is explicit and auditable. The
    // Job Card/workflow update is already committed before notification, so
    // email failures never make the Technician lose the technical report.
    $customerDelivery=['sent'=>0,'failed'=>0,'recipients'=>[]];
    $belmDelivery=['sent'=>0,'failed'=>0,'recipients'=>[]];
    $portalCommunicationId=null;
    $customerSubject='TECHNICIAN JOB CARD UPDATE - '.$job['job_card_no'];
    $jobReportStatus=($requiredSpare!==''||$activeSpareCount>0)?'Waiting for Parts':($complete?'Pending Approval':'Diagnosis Report / In progress');
    $customerBody="Job Card: {$job['job_card_no']}\nTechnician: {$ctx['actorName']}\nDiagnosis: $diagnosis\nWork done: $work\nStatus: $jobReportStatus".(($requiredSpare!==''||$activeSpareNames!=='')?"\nRequired spare: ".($requiredSpare?:$activeSpareNames):'').($repeat?'\nRepeat/Rework: YES':'');
    $managerScope = ($ctx['kind'] ?? '') === 'belm' ? 'BELM' : 'CUSTOMER';
    bw_role_message($ctx,$case,$managerScope,'workshop_manager',$customerSubject,$customerBody,
        ($requiredSpare!==''||$activeSpareCount>0||$complete)?'ATTENTION':'NORMAL','job_card',(string)$job['id']);
    if ($requiredSpare!=='' && $spareCreated) {
        bw_role_message($ctx,$case,'CUSTOMER','customer_admin','SPARE APPROVAL REQUIRED - JOB CARD '.$job['job_card_no'],
            "Required spare from Technician diagnosis: $requiredSpare x $requiredSpareQty. Approve/reject it in Maintenance Process.",'ATTENTION','job_card',(string)$job['id']);
    }
    try {
        $customerDelivery=customer_send_team_alert((string)$case['customer_id'],['workflow','check-up'],$customerSubject,$customerBody,true);
    } catch(Throwable $e) {}

    // Any BELM-owned Technician who can update this Job Card must notify BELM,
    // including official Support Requests for a self-managed Customer. V323
    // incorrectly skipped that latter case because is_machinery_admin=1.
    if ($ctx['kind']==='belm') {
        $portalCommunicationId=belm_log_customer_communication(
            (string)$case['customer_id'],
            (string)$job['machine_id'],
            'BELM_TO_CUSTOMER',
            'PORTAL',
            $customerSubject,
            $customerBody,
            'JOB_CARD',
            (string)$job['id'],
            (string)$ctx['actorName'],
            'SENT'
        );
        try {
            $belmDelivery=belm_send_customer_to_belm_alert(
                ['job-cards','service-requests'],
                'BELM TECHNICIAN JOB CARD UPDATE - '.$job['job_card_no'],
                "Technician: {$ctx['actorName']}\nMachine: ".$case['brand'].' '.$case['model']."\nDiagnosis: $diagnosis\nWork done: $work\nStatus: $jobReportStatus".(($requiredSpare!==''||$activeSpareNames!=='')?"\nRequired spare: ".($requiredSpare?:$activeSpareNames):'')
            );
        } catch(Throwable $e) {}
    }
    json_out([
        'ok'=>true,
        'repeatIssue'=>$repeat,
        'requiredSpare'=>$requiredSpare,
        'spareRequestCreated'=>$spareCreated,
        'delivery'=>[
            'customer'=>[
                'portalRecorded'=>true,
                'emailsSent'=>(int)($customerDelivery['sent']??0),
                'emailFailures'=>(int)($customerDelivery['failed']??0),
            ],
            'belm'=>[
                'required'=>$ctx['kind']==='belm',
                'workflowSynced'=>true,
                'portalCommunicationId'=>$portalCommunicationId,
                'emailsSent'=>(int)($belmDelivery['sent']??0),
                'emailFailures'=>(int)($belmDelivery['failed']??0),
            ],
        ],
    ]);
}


// V410 - final Job Card closure is a reviewer decision, never a Technician action.
// Official Customer -> BELM jobs are reviewed by BELM Super Admin / Engineer.
// Customer-internal jobs are reviewed by that Customer's Admin / Workshop Manager.
if ($method === 'PUT' && $action === 'job-approval' && $id !== '') {
    $stmt=db()->prepare('SELECT jc.*,bc.source_type,bc.source_id,bc.status AS case_status,c.is_machinery_admin FROM digital_job_cards jc JOIN breakdown_cases bc ON bc.id=jc.case_id JOIN customers c ON c.id=jc.customer_id WHERE jc.id=?');
    $stmt->execute([$id]);
    $job=$stmt->fetch();
    if(!$job) json_error('Job Card not found.',404);
    $case=bw_case_access($ctx,(string)$job['case_id']);
    if(bw_is_technician_actor($ctx)) json_error('Technicians cannot approve their own Job Cards.',403);
    $officialBelmJob=strtoupper((string)($job['source_type']??''))==='SERVICE_REQUEST' || $ctx['kind']==='belm';
    if($officialBelmJob){
        if($ctx['kind']!=='belm' || empty($ctx['canApproveJob'])) json_error('BELM Super Admin or Workshop Manager approval is required for this Job Card.',403);
    }else{
        if($ctx['kind']!=='customer' || empty($ctx['canApproveJob']) || empty($job['is_machinery_admin'])) json_error('Customer Admin or Workshop Manager approval is required for this internal Job Card.',403);
    }
    if(strtoupper((string)$job['status'])!=='PENDING_APPROVAL') json_error('Only a Job Card in Pending Approval can be reviewed.',409);
    $b=body(); $approve=!empty($b['approve']); $note=trim((string)($b['note']??''));
    if(!$approve && $note==='') json_error('Enter a reason before returning the Job Card to the Technician.');
    if($approve){
        db()->prepare("UPDATE digital_job_cards SET status='COMPLETED',reviewed_at=NOW(),reviewed_by_name=?,review_note=?,completed_at=NOW(),updated_at=NOW() WHERE id=?")
            ->execute([$ctx['actorName'],$note?:null,$id]);
        bw_set_stage((string)$job['case_id'],'COMPLETED',null,$ctx,'Job Card approved - machine returned to service');
        try {
            $mail=db()->prepare('SELECT email FROM users WHERE id=?'); $mail->execute([(string)($job['technician_id']??'')]);
            $email=trim((string)$mail->fetchColumn());
            if(filter_var($email,FILTER_VALIDATE_EMAIL)) send_email($email,'JOB CARD APPROVED - '.$job['job_card_no'],"Job Card {$job['job_card_no']} has been approved by {$ctx['actorName']}.\nStatus: COMPLETED".($note!==''?"\nReview note: $note":''));
        } catch(Throwable $e) {}
        json_out(['ok'=>true,'status'=>'COMPLETED','message'=>'Job Card approved and closed.']);
    }
    db()->prepare("UPDATE digital_job_cards SET status='IN_PROGRESS',reviewed_at=NOW(),reviewed_by_name=?,review_note=?,completed_at=NULL,updated_at=NOW() WHERE id=?")
        ->execute([$ctx['actorName'],$note,$id]);
    bw_set_stage((string)$job['case_id'],'REPAIR',$note,$ctx,'Job Card returned to Technician for correction / additional work');
    try {
        $mail=db()->prepare('SELECT email FROM users WHERE id=?'); $mail->execute([(string)($job['technician_id']??'')]);
        $email=trim((string)$mail->fetchColumn());
        if(filter_var($email,FILTER_VALIDATE_EMAIL)) send_email($email,'JOB CARD RETURNED - '.$job['job_card_no'],"Job Card {$job['job_card_no']} was returned by {$ctx['actorName']}.\nReason: $note\nOpen My Job Cards and update the report.");
    } catch(Throwable $e) {}
    json_out(['ok'=>true,'status'=>'IN_PROGRESS','message'=>'Job Card returned to Technician.']);
}

if ($method === 'PUT' && $action === 'stage' && $id !== '') {
    if (bw_is_technician_actor($ctx)) json_error('Technicians update work through My Job Cards; main Maintenance Process stages are restricted.',403);
    $case=bw_case_access($ctx,$id); $b=body(); $stage=strtoupper(trim((string)($b['stage']??''))); $note=trim((string)($b['note']??''));
    if($ctx['kind']==='customer' && !$ctx['isOwner'] && !in_array($ctx['role'],['workshop_manager','admin'],true)) json_error('Only Workshop Manager or Administration can move the main breakdown stage.',403);
    if($ctx['kind']==='customer-tech') json_error('Technicians update the process through their Digital Job Card report.',403);
    if (in_array($stage, ['JOB_CARD_ASSIGNED','DIAGNOSIS','REPAIR'], true)) {
        $assignedJob = db()->prepare("SELECT 1 FROM digital_job_cards WHERE case_id=? AND status NOT IN ('COMPLETED','CANCELLED') AND technician_id IS NOT NULL LIMIT 1");
        $assignedJob->execute([$id]);
        if (!$assignedJob->fetchColumn()) {
            json_error('Assign a Technician to the active Job Card before moving this case to Technician Diagnosis/Repair.',409);
        }
    }
    if ($stage === 'COMPLETED') {
        // V307: a Job Card cannot skip the Technician Job Card / Workshop
        // test simply by moving the main process directly to COMPLETED.
        $jobCount = db()->prepare(
            "SELECT COUNT(*) AS total,
                    COUNT(*) FILTER (WHERE status='COMPLETED') AS completed
             FROM digital_job_cards WHERE case_id=?"
        );
        $jobCount->execute([$id]);
        $jobs = $jobCount->fetch() ?: ['total'=>0,'completed'=>0];
        $totalJobs = (int)($jobs['total'] ?? 0);
        $completedJobs = (int)($jobs['completed'] ?? 0);
        if (($case['source_type'] ?? '') === 'SERVICE_REQUEST' && $totalJobs === 0) {
            json_error('Create and complete the Job Card before Workshop closure.',409);
        }
        if ($totalJobs > 0 && $completedJobs !== $totalJobs) {
            json_error('All Job Cards must be completed before Workshop can return the machine to service.',409);
        }
    }
    bw_set_stage($id,$stage,$note?:null,$ctx,$stage==='COMPLETED'?'Machine returned to service':'Workflow stage updated'); json_out(['ok'=>true]);
}

json_error('Unknown breakdown workflow request.',404);
