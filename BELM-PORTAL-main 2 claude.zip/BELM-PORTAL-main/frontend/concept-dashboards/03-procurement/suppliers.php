<?php
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Location: /suppliers-manager/?module=procurement', true, 302);
exit;
