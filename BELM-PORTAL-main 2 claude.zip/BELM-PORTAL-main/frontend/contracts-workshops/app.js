(()=>{
  const token=localStorage.getItem('belm_admin_token');
  const H={'Content-Type':'application/json',Authorization:`Bearer ${token||''}`};
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  async function api(p,o={}){const r=await fetch('/api'+p,{...o,headers:{...H,...(o.headers||{})}});const d=await r.json().catch(()=>null);if(!r.ok)throw Error(d?.error||'Request failed');return d}
  function stat(n,l){return `<div class="stat"><strong>${esc(n)}</strong><span>${esc(l)}</span></div>`}
  function sourceLabel(x){return x.supportMode==='BELM_SUPPORT'?'BELM SUPPORT':'CUSTOMER WORKSHOP'}
  async function load(){
    try{
      const [s,c,o,customers]=await Promise.all([api('/contracts/summary'),api('/contracts'),api('/workshops/orders'),api('/customers')]);
      document.querySelector('#stats').innerHTML=stat(s.activeContracts||0,'ACTIVE CONTRACTS')+stat(s.coveredMachines||0,'CUSTOMER MACHINES COVERED')+stat(s.renewalsDue||0,'RENEWALS ≤ 60 DAYS')+stat(s.slaAtRisk||0,'JOB CARDS OVER SLA');
      document.querySelector('#contracts').innerHTML=c.length?c.map(x=>`<article class="card"><div class="cardTop"><div><b>${esc(x.customer?.name)}</b><div>${esc(x.contractNumber)}</div></div><span class="badge">${esc(x.status)}</span></div><div class="meta"><span>${esc(x.title)}</span><span>${esc(x.startDate)} → ${esc(x.endDate)}</span><span>SLA: ${esc(x.slaResponseHours)}h · ${esc(x.daysRemaining)} days remaining</span></div></article>`).join(''):'<div class="empty">No contracts yet.</div>';
      document.querySelector('#orders').innerHTML=o.length?o.map(x=>`<article class="order"><div><b>${esc(x.workOrderNumber)} · ${esc(x.title)}</b><small>${esc(x.customerName)} · ${esc(x.machineModel||'No machine')} · ${esc(x.contractNumber||'No active contract')}</small></div><span>${esc(sourceLabel(x))}</span><span class="badge">${esc(x.currentStage||x.status)}</span><a class="openJob" href="/breakdown-workflow/?actor=admin&case=${encodeURIComponent(x.caseId||'')}">Open Job Card</a></article>`).join(''):'<div class="empty">No digital Job Cards yet.</div>';
      const sel=document.querySelector('#customerId');
      sel.innerHTML='<option value="">Select customer</option>'+customers.map(x=>`<option value="${esc(x.id)}">${esc(x.name)}</option>`).join('');
    }catch(e){alert(e.message)}
  }
  document.querySelector('#newContract').onclick=()=>document.querySelector('#contractDialog').showModal();
  document.querySelector('#cancel').onclick=()=>document.querySelector('#contractDialog').close();
  document.querySelector('#refresh').onclick=load;
  document.querySelector('#contractForm').onsubmit=async e=>{e.preventDefault();try{await api('/contracts',{method:'POST',body:JSON.stringify({customerId:customerId.value,contractNumber:contractNumber.value,title:title.value,startDate:startDate.value,endDate:endDate.value,slaResponseHours:+sla.value,preventiveMaintenanceIncluded:true,labourIncluded:true,partsIncluded:false,notes:notes.value})});contractDialog.close();e.target.reset();load()}catch(err){alert(err.message)}};
  load();
})();
