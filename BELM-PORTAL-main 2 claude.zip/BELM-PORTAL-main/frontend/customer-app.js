(function(){
  const parts=location.pathname.split('/').filter(Boolean);
  const slug=(parts[0]==='app' && parts[1] ? decodeURIComponent(parts[1]) : '').toLowerCase();
  const isBelm=slug==='belm'||/@belm$/i.test(slug);
  const isTechBelm=slug==='tech@belm';
  const companyName=document.getElementById('companyName');
  const companyNote=document.getElementById('companyNote');
  const chip=document.getElementById('customerChip');
  const hint=document.getElementById('loginHint');
  const form=document.getElementById('loginForm');
  const email=document.getElementById('email');
  const password=document.getElementById('password');
  const passwordToggle=document.getElementById('loginPasswordToggle');
  const button=document.getElementById('loginButton');
  const errorBox=document.getElementById('errorBox');
  const installButton=document.getElementById('installButton');
  let installPrompt=null;
  let loginPending=false;

  async function fetchWithTimeout(url,options={},timeoutMs=70000,onSlow=null){
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),timeoutMs);
    let slowTimer=null;
    if(typeof onSlow==='function')slowTimer=setTimeout(onSlow,5000);
    try{return await fetch(url,{...options,signal:controller.signal})}
    finally{clearTimeout(timer);if(slowTimer)clearTimeout(slowTimer)}
  }

  async function readJsonResponse(res){
    const text=await res.text();
    try{return JSON.parse(text)}
    catch(_err){
      console.error('BELM API returned a non-JSON response',text.slice(0,240));
      throw new Error('Portal API response was invalid. Refresh once after deployment and try again.');
    }
  }

  function clearRoleSessions(){['belm_customer_token','belm_tech_token','belm_tech_user','belm_admin_token','belm_admin_user','belm_operator_token'].forEach(k=>localStorage.removeItem(k))}
  function setActiveAccount(type){localStorage.setItem('belm_active_account_type',type)}

  async function loadContext(){
    if(isBelm){companyName.textContent=isTechBelm?'TECH@BELM':(slug==='belm'?'BELM General Tech':slug.toUpperCase());companyNote.textContent=isTechBelm?'BELM Technician workspace.':'BELM staff operations workspace.';chip.textContent=isTechBelm?'TECH@BELM':'@BELM STAFF';chip.hidden=false;return}
    if(!slug){companyName.textContent='BELM Portal Login';companyNote.textContent='One secure login for BELM staff, Technicians and customer teams.';hint.textContent='You can edit the email / portal ID and password at any time. Press Login to sign in.';return}
    try{
      const res=await fetchWithTimeout('/api/auth/customer-context?customer='+encodeURIComponent(slug),{cache:'no-store'},70000);
      if(!res.ok)throw new Error('Customer app link was not found.');
      const data=await res.json();
      companyName.textContent=data.name;
      companyNote.textContent='Operations workspace powered by BELM General Tech.';
      chip.textContent=data.name.toUpperCase(); chip.hidden=false;
      document.title=data.name+' - BELM Operations';
    }catch(err){showError(err.message||'Customer app link was not found.');button.disabled=true}
  }
  function showError(msg){errorBox.textContent=msg;errorBox.hidden=false}
  function clearError(){errorBox.hidden=true;errorBox.textContent=''}
  async function login(){
    if(loginPending||!form.reportValidity())return;
    loginPending=true;
    clearError(); button.disabled=true; button.textContent='Opening Home Dashboard...';
    try{
      const payload={email:email.value.trim(),password:password.value};
      if(slug && !isBelm)payload.customerSlug=slug;
      if(isBelm)payload.customerSlug='belm';
      const res=await fetchWithTimeout('/api/auth/unified-login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)},70000,()=>{button.textContent='Server waking up…'});
      const data=await readJsonResponse(res); if(!res.ok)throw new Error(data.error||'Login failed.');
      clearRoleSessions();
      if(data.accountType==='customer'){
        localStorage.setItem('belm_customer_token',data.token); setActiveAccount('customer');
      }else if(data.accountType==='technician'){
        localStorage.setItem('belm_tech_token',data.token);
        localStorage.setItem('belm_tech_user',JSON.stringify(data.user||{})); setActiveAccount('technician');
      }else{
        localStorage.setItem('belm_admin_token',data.token);
        localStorage.setItem('belm_admin_user',JSON.stringify(data.user||{})); setActiveAccount('admin');
      }
      location.replace('/portal-v2/');
    }catch(err){
      const timedOut=err&&err.name==='AbortError';
      showError(timedOut?'Server did not respond in time. Tap Login to try again.':(err.message||'Login failed.'));
      loginPending=false;button.disabled=false;button.textContent='Login';
    }
  }

  function ensureEditable(){
    [email,password].forEach(input=>{
      if(!input)return;
      input.disabled=false;
      input.readOnly=false;
      input.removeAttribute('disabled');
      input.removeAttribute('readonly');
      input.removeAttribute('aria-disabled');
    });
  }

  function bindDirectEditing(input){
    if(!input||input.dataset.belmDirectEditBound==='1')return;
    input.dataset.belmDirectEditBound='1';
    input.addEventListener('input',clearError);
    ['pointerdown','mousedown','touchstart','focus','keydown','beforeinput','animationstart'].forEach(type=>{
      input.addEventListener(type,ensureEditable,{capture:true});
    });
  }

  ensureEditable();
  bindDirectEditing(email);
  bindDirectEditing(password);

  form.addEventListener('submit',event=>{
    event.preventDefault();
    ensureEditable();
    login();
  });
  passwordToggle?.addEventListener('click',()=>{
    const show=password.type==='password';
    password.type=show?'text':'password';
    passwordToggle.setAttribute('aria-label',show?'Hide password or PIN':'Show password or PIN');
    password.focus({preventScroll:true});
  });

  window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;installButton.hidden=false});
  installButton.addEventListener('click',async()=>{if(!installPrompt)return;installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;installButton.hidden=true});
  if('serviceWorker' in navigator){window.addEventListener('load',()=>{
    navigator.serviceWorker.controller?.postMessage({type:'CLEAR_BELM_CACHES'});
    navigator.serviceWorker.getRegistrations().then(registrations=>Promise.all(registrations.map(registration=>registration.unregister()))).catch(()=>{});
  })}

  // V834: credential fields remain the exact native inputs parsed from HTML.
  // Never clone, re-parent or replace them: Chrome/Edge Password Manager retains a
  // stable target while each mouse, keyboard and autofill event confirms editability.
  window.addEventListener('pageshow',()=>{
    loginPending=false;
    ensureEditable();
    button.disabled=false;
    button.textContent='Login';
  });

  // Saved credentials may autofill, but only submitting the Login form signs in.
  ensureEditable();
  loadContext();
})();
