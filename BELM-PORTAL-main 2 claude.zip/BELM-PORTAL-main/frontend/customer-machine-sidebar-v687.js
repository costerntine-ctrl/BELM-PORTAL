(function(){
  'use strict';
  const q=new URLSearchParams(location.search);
  if(!/^\/portal\/dashboard\/?$/.test(location.pathname)||q.get('view')!=='machines'||!localStorage.getItem('belm_customer_token'))return;
  if(window.__belmCustomerMachineSidebarV800)return;
  window.__belmCustomerMachineSidebarV800=true;

  const dailyChecklistFocus=q.get('focus')==='daily-checklist';
  const activeKey=dailyChecklistFocus?'checklist':'machines';
  const items=[
    ['machines','MC','Customer Machines','/portal/dashboard?view=machines'],
    ['checklist','DC','Daily Checklist','/portal/dashboard?view=machines&focus=daily-checklist'],
    ['jobs','JC','Open Job Cards','/breakdown-workflow/?actor=customer'],
    ['store','ST','Store & Spares','/customer-store/'],
    ['procurement','PR','Procurement','/customer-procurement-home/'],
    ['technicians','TC','Technicians','/customer-technicians/'],
    ['analysis','WA','Workshop Analysis','/workshop-analysis/'],
    ['reports','GR','General Report','/general-report/'],
    ['petty','PC','Petty Cash','/customer-petty-cash/'],
    ['general','GA','General Analysis','/general-analysis/'],
    ['settings','SE','Settings','/customer-settings-center/']
  ];
  const shade=document.createElement('div');shade.className='cwm-machine-shade';
  const menu=document.createElement('button');menu.type='button';menu.className='cwm-machine-menu';menu.setAttribute('aria-expanded','false');menu.innerHTML='<b>&#9776;</b> Menu';
  const side=document.createElement('aside');side.className='cwm-machine-side';side.setAttribute('aria-label','Customer machine navigation');side.innerHTML='<button class="cwm-machine-side-close" type="button" aria-label="Close menu">&times;</button><div class="cwm-machine-side-head"><small>WORKSHOP CONTROL</small><strong id="cwmMachineSideTitle">Customer Menu</strong></div><nav>'+items.map(x=>`<a data-side-key="${x[0]}" class="${x[0]===activeKey?'is-active':''}" href="${x[3]}"${x[0]===activeKey?' aria-current="page"':''}><i>${x[1]}</i>${x[2]}</a>`).join('')+'</nav>';
  document.body.append(shade,menu,side);document.body.classList.add('cwm-machine-sidebar-ready');
  if(dailyChecklistFocus)document.body.classList.add('cwm-daily-checklist-focus');

  const setOpen=open=>{side.classList.toggle('is-open',open);shade.classList.toggle('is-open',open);menu.setAttribute('aria-expanded',String(open));document.body.style.overflow=open?'hidden':''};
  menu.onclick=()=>setOpen(true);shade.onclick=()=>setOpen(false);side.querySelector('.cwm-machine-side-close').onclick=()=>setOpen(false);side.querySelectorAll('a').forEach(a=>a.onclick=()=>setOpen(false));addEventListener('keydown',e=>{if(e.key==='Escape')setOpen(false)});addEventListener('resize',()=>{if(innerWidth>900)setOpen(false)});

  if(dailyChecklistFocus){
    let scrolled=false;
    const highlight=()=>{
      const targets=[...document.querySelectorAll('[data-customer-checkup]')];
      targets.forEach(btn=>{btn.classList.add('cwm-daily-checklist-target');btn.setAttribute('title','Open Daily Checklist for this machine')});
      if(!scrolled&&targets.length){scrolled=true;setTimeout(()=>targets[0].scrollIntoView({behavior:'smooth',block:'center'}),180)}
      return targets.length;
    };
    if(!highlight()){
      const root=document.getElementById('root')||document.body;
      const observer=new MutationObserver(()=>{if(highlight())observer.disconnect()});
      observer.observe(root,{childList:true,subtree:true});
      setTimeout(()=>observer.disconnect(),12000);
    }
  }

  fetch('/api/customer-portal/dashboard',{cache:'no-store',headers:{Authorization:`Bearer ${localStorage.getItem('belm_customer_token')}`}}).then(r=>r.ok?r.json():null).then(d=>{if(!d)return;const p=d.customer||{},role=String(p.actorRole||'assistant').toLowerCase().replace(/\s+/g,'_'),owner=['owner','admin'].includes(role),manager=owner||role==='workshop_manager';document.getElementById('cwmMachineSideTitle').textContent=(p.name||'Customer')+' Menu';const show=(k,on)=>{const a=side.querySelector(`[data-side-key="${k}"]`);if(a)a.hidden=!on};show('checklist',manager||['operator','technician'].includes(role));show('jobs',manager);show('store',owner||['store_keeper','workshop_manager','procurement'].includes(role));show('procurement',owner||['procurement','workshop_manager'].includes(role));show('technicians',!p.belmServiceProviderActive&&manager);show('analysis',manager);show('reports',role!=='operator');show('petty',owner||role==='accounts');show('general',owner||['workshop_manager','accounts'].includes(role));show('settings',manager)}).catch(()=>{});
})();
