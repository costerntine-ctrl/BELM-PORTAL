(function(){
  'use strict';
  if(window.__BELM_JOB_CARD_MANAGER_V814)return;
  window.__BELM_JOB_CARD_MANAGER_V814=true;

  const hostBody=document.body;
  const actor=String(hostBody?.dataset?.jobActor||new URLSearchParams(location.search).get('actor')||'admin').toLowerCase()==='customer'?'customer':'admin';
  const token=actor==='customer'?(localStorage.getItem('belm_customer_token')||''):(localStorage.getItem('belm_admin_token')||'');
  if(!token)return;
  const frame=document.getElementById('workflowFrame');
  const processSteps=['Create & Assign','Receive','Diagnosis / Inspection','Manager Review','Maintenance / Spare','Testing','Final Result','Report'];
  let childDoc=null;
  let childWin=null;
  let items=[];
  let cases=[];
  let technicians=[];
  let busy=false;
  let listFilter='active';
  const pageParams=new URLSearchParams(location.search);
  let workspacePage=['create','process','detail'].includes(pageParams.get('jcSection'))?pageParams.get('jcSection'):'list';
  let selectedJob=pageParams.get('jobId')||'';
  function workspaceUrl(page,id=''){const u=new URL(location.href);u.searchParams.set('jcSection',page);u.searchParams.delete('jobId');if(id)u.searchParams.set('jobId',id);return u.pathname+u.search;}
  function navigateWorkspace(page,id=''){workspacePage=page;selectedJob=String(id);history.pushState({},'',workspaceUrl(page,id));showWorkspace();childWin.scrollTo?.(0,0);}
  window.addEventListener('popstate',()=>{const p=new URLSearchParams(location.search);workspacePage=['create','process','detail'].includes(p.get('jcSection'))?p.get('jcSection'):'list';selectedJob=p.get('jobId')||'';showWorkspace();});

  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const up=v=>String(v||'').trim().toUpperCase();
  const val=(o,...keys)=>{for(const k of keys){if(o&&o[k]!==undefined&&o[k]!==null)return o[k]}return''};
  const fmtDateTime=v=>{
    const text=String(v||'').trim();if(!text)return '—';
    const d=new Date(text.includes('T')?text:text.replace(' ','T'));
    if(Number.isNaN(d.getTime()))return text;
    return new Intl.DateTimeFormat(undefined,{year:'numeric',month:'short',day:'2-digit',hour:'2-digit',minute:'2-digit'}).format(d);
  };

  async function request(url,opt={}){
    const r=await fetch(url,{...opt,cache:'no-store',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`,...(opt.headers||{})}});
    const type=String(r.headers.get('content-type')||'');
    if(type.includes('application/pdf'))return r;
    const text=await r.text();let data=null;try{data=text?JSON.parse(text):null}catch{}
    if(!r.ok)throw new Error(data?.error||`Request failed (${r.status}).`);
    return data;
  }
  const processApi=(action,opt={})=>request(`/api/job-card-workflow-v814?action=${encodeURIComponent(action)}${opt.id?`&id=${encodeURIComponent(opt.id)}`:''}`,opt.fetch||{});
  const workflowApi=(path,opt={})=>request(`/api/breakdown-workflow${path}`,opt);

  function ensureStyle(doc){
    if(doc.getElementById('jobCardManagerV814Style'))return;
    const s=doc.createElement('style');s.id='jobCardManagerV814Style';s.textContent=`
      html.belm-single-job-control #summaryCards,html.belm-single-job-control main>.filters,html.belm-single-job-control .jc-ref-head,html.belm-single-job-control #jobProcessPanel,html.belm-single-job-control #dispatchPanel{display:none!important}
      .jcm814{margin:0 0 14px;border:1px solid var(--line);border-radius:15px;background:var(--surface);overflow:hidden;box-shadow:0 7px 24px rgba(10,30,55,.06)}
      .jcm814-head{display:flex;justify-content:space-between;gap:14px;align-items:center;padding:15px 16px;border-bottom:1px solid var(--line)}
      .jcm814-head h2{margin:0 0 3px;font-size:18px}.jcm814-head p{margin:0;color:var(--muted);font-size:11px}.jcm814-head .scope{padding:6px 10px;border-radius:999px;background:#0b3154;color:#fff;font-size:10px;font-weight:900;white-space:nowrap}
      .jcm814-flow{display:grid;grid-template-columns:repeat(8,minmax(86px,1fr));gap:5px;padding:11px 14px;border-bottom:1px solid var(--line);background:color-mix(in srgb,var(--surface) 92%,#0b67c2 8%)}
      .jcm814-flow>span{min-height:46px;display:grid;place-items:center;text-align:center;padding:6px 5px;border:1px solid var(--line);border-radius:9px;color:var(--muted);font-size:9px;font-weight:900;line-height:1.2;text-transform:uppercase}
      .jcm814-create{display:grid;grid-template-columns:1.2fr 1fr 1fr 1.2fr;gap:9px;padding:13px 14px;border-bottom:1px solid var(--line)}
      .jcm814-create label{font-size:10px;font-weight:850;color:var(--muted)}.jcm814-create select,.jcm814-create input,.jcm814-create textarea{width:100%;margin-top:5px;padding:9px 10px;border:1px solid var(--line);border-radius:9px;background:var(--surface);color:var(--ink)}
      .jcm814-create .wide{grid-column:span 2}.jcm814-actions{grid-column:1/-1;display:flex;align-items:center;justify-content:space-between;gap:10px}.jcm814-note{font-size:10px;color:var(--muted);line-height:1.4}.jcm814-note.ok{color:#16834e}.jcm814-note.error{color:#c72f2f}.jcm814-button{border:0;border-radius:9px;padding:10px 14px;background:#0b67c2;color:#fff;font-weight:900;cursor:pointer}.jcm814-button.green{background:#09834a}.jcm814-button:disabled{opacity:.55;cursor:not-allowed}
      .jcm814-toolbar{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 14px;border-bottom:1px solid var(--line);flex-wrap:wrap}.jcm814-toolbar b{font-size:12px}.jcm814-toolbar span{font-size:10px;color:var(--muted)}.jcm814-toolbar-actions{display:flex;align-items:center;gap:7px;flex-wrap:wrap}.jcm814-filter{border:1px solid var(--line);border-radius:999px;padding:7px 11px;background:var(--surface);color:var(--ink);font-size:9px;font-weight:900;cursor:pointer}.jcm814-filter.active{background:#0b67c2;color:#fff;border-color:#0b67c2}.jcm814-problem{max-width:260px;white-space:normal;line-height:1.35}.jcm814-dates{white-space:nowrap}.jcm814-dates small{white-space:nowrap}
      .jcm814-table-wrap{overflow:auto;padding:0 10px 12px}.jcm814-table{width:100%;min-width:1180px;border-collapse:separate;border-spacing:0 7px}.jcm814-table th{padding:4px 8px;text-align:left;color:var(--muted);font-size:9px;text-transform:uppercase}.jcm814-table td{padding:10px 8px;background:var(--bg);border-top:1px solid var(--line);border-bottom:1px solid var(--line);font-size:11px;vertical-align:top}.jcm814-table td:first-child{border-left:1px solid var(--line);border-radius:10px 0 0 10px}.jcm814-table td:last-child{border-right:1px solid var(--line);border-radius:0 10px 10px 0}.jcm814-table small{display:block;margin-top:3px;color:var(--muted);line-height:1.35}.jcm814-badge{display:inline-flex;padding:5px 8px;border-radius:999px;background:#e7f1ff;color:#0b5ca8;font-size:9px;font-weight:900;text-transform:uppercase}.jcm814-badge.pending{background:#fff4c1;color:#6b5600}.jcm814-badge.ok{background:#e4f7ec;color:#08683b}.jcm814-badge.red{background:#fee8e8;color:#9a2222}.jcm814-ground{font-size:15px;font-weight:900}.jcm814-row-actions{display:flex;flex-wrap:wrap;gap:5px}.jcm814-row-actions button{border:1px solid var(--line);border-radius:7px;padding:6px 8px;background:var(--surface);color:var(--ink);font-size:9px;font-weight:850;cursor:pointer}.jcm814-row-actions .approve{background:#09834a;color:#fff;border-color:#09834a}.jcm814-row-actions .return{background:#fee8e8;color:#9a2222;border-color:#efb7b7}
      .jcm814-step-track{display:grid;grid-template-columns:repeat(8,1fr);gap:2px;margin-top:6px}.jcm814-step-track i{height:5px;border-radius:4px;background:#d7e0ea}.jcm814-step-track i.done{background:#09834a}.jcm814-step-track i.current{background:#f2c318}
      .jcm814-register-toolbar{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:13px 14px 8px;border-top:1px solid var(--line);background:color-mix(in srgb,var(--surface) 96%,#0b67c2 4%)}.jcm814-register-toolbar b{font-size:13px}.jcm814-register-toolbar span{font-size:10px;color:var(--muted)}.jcm814-register-scope{padding:5px 9px;border:1px solid var(--line);border-radius:999px;white-space:nowrap}
      .jcm814-register-wrap{overflow:auto;padding:0 10px 14px;background:color-mix(in srgb,var(--surface) 96%,#0b67c2 4%)}.jcm814-register-table{width:100%;min-width:1540px;border-collapse:collapse;border:1px solid var(--line);border-radius:10px;overflow:hidden}.jcm814-register-table th{padding:9px 8px;text-align:left;color:var(--muted);font-size:9px;text-transform:uppercase;white-space:nowrap;background:var(--bg);border-bottom:1px solid var(--line)}.jcm814-register-table td{padding:10px 8px;font-size:10px;vertical-align:top;border-bottom:1px solid var(--line);white-space:nowrap}.jcm814-register-table tbody tr:last-child td{border-bottom:0}.jcm814-register-table .problem{white-space:normal;min-width:230px;max-width:340px;line-height:1.4}.jcm814-register-table .process{white-space:normal;min-width:150px}.jcm814-register-table small{display:block;margin-top:3px;color:var(--muted);line-height:1.35}.jcm814-register-empty{text-align:center!important;color:var(--muted)!important;padding:18px!important}
      html[data-theme="dark"] .jcm814-badge{background:#143154;color:#a8d0ff}html[data-theme="dark"] .jcm814-badge.pending{background:#403511;color:#f7d96d}html[data-theme="dark"] .jcm814-badge.ok{background:#153b2b;color:#8ee4b6}html[data-theme="dark"] .jcm814-badge.red{background:#401d23;color:#ffaaaa}
      @media(max-width:1000px){.jcm814-flow{grid-template-columns:repeat(4,1fr)}.jcm814-create{grid-template-columns:1fr 1fr}.jcm814-create .wide{grid-column:1/-1}}
      @media(max-width:620px){.jcm814-flow{grid-template-columns:repeat(2,1fr)}.jcm814-create{grid-template-columns:1fr}.jcm814-create .wide{grid-column:auto}.jcm814-actions{align-items:stretch;flex-direction:column}.jcm814-button{width:100%}.jcm814-register-toolbar{align-items:flex-start;flex-direction:column}}
      .jcm92-menu{display:flex;flex-wrap:wrap;gap:8px;padding:14px;border-bottom:1px solid var(--line)}.jcm92-menu a{padding:10px 14px;border:1px solid var(--line);border-radius:9px;text-decoration:none;color:var(--ink);font-weight:700;font-size:14px}.jcm92-menu a[aria-current]{background:#0b67c2;color:white;border-color:#0b67c2}
      #jcm92Status{margin:0;padding:10px 14px;font-size:13px;color:var(--muted)}#jcm92Status.error{color:#d13232}
      .jcm814[data-page] .jcm814-flow,.jcm814[data-page] .jcm814-create,.jcm814[data-page] .jcm814-toolbar,.jcm814[data-page] .jcm814-table-wrap{display:none}
      .jcm814[data-page="list"] .jcm814-toolbar{display:flex}.jcm814[data-page="list"] .jcm814-table-wrap{display:block}.jcm814[data-page="create"] .jcm814-create{display:grid}.jcm814[data-page="process"] .jcm814-flow{display:grid}
      #jcm92Detail{padding:18px}#jcm92Detail[hidden]{display:none}.jcm92-facts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.jcm92-facts>div{padding:12px;border:1px solid var(--line);border-radius:9px}.jcm92-facts dt{font-size:12px;color:var(--muted);margin-bottom:6px}.jcm92-facts dd{margin:0;white-space:pre-wrap;overflow-wrap:anywhere;font-size:14px;line-height:1.5}
      .jcm814-table{min-width:760px}.jcm814-table th,.jcm814-table td{font-size:13px}.jcm814-table small{font-size:12px}.jcm814-row-actions button{font-size:13px;padding:9px 11px}.jcm814-table :is(th,td):nth-child(3),.jcm814-table :is(th,td):nth-child(4),.jcm814-table :is(th,td):nth-child(7),.jcm814-table :is(th,td):nth-child(8){display:none}.jcm814-create label{font-size:13px}.jcm814-head p{font-size:13px}.jcm814-create label:has(#jcm814CaseType){display:none}
      @media(max-width:620px){.jcm92-facts{grid-template-columns:1fr}.jcm92-menu a{flex:1;text-align:center}.jcm814-head{align-items:start;flex-direction:column}}
    `;doc.head.appendChild(s);
  }

  function mount(){
    const doc=frame?frame.contentDocument:document;
    const win=frame?frame.contentWindow:window;
    if(!doc||!doc.body)return;
    childDoc=doc;childWin=win;ensureStyle(doc);
    doc.documentElement.classList.add('belm-single-job-control');
    if(doc.getElementById('jobCardManagerV814')){refresh();return;}
    const grid=doc.querySelector('.grid');
    if(!grid)return;
    const root=doc.createElement('section');root.id='jobCardManagerV814';root.className='jcm814';
    root.innerHTML=`
      <div class="jcm814-head"><div><h2>Job Cards</h2><p>Assign work, follow progress and review completed reports.</p></div><span class="scope">${actor==='customer'?'CUSTOMER WORKSHOP':'BELM WORKSHOP'}</span></div>
      <nav class="jcm92-menu" aria-label="Job Card menu"><a href="${esc(workspaceUrl('list'))}" data-jc-page="list">Active Job Cards</a><a href="${esc(workspaceUrl('create'))}" data-jc-page="create">Create & Assign</a><a href="${esc(workspaceUrl('process'))}" data-jc-page="process">Process Guide</a><a id="jcm92Completed" target="_top">Completed Reports</a></nav><p id="jcm92Status" role="status" aria-live="polite"></p><section id="jcm92Detail" hidden></section>
      <div class="jcm814-flow">${processSteps.map((x,i)=>`<span>${i+1}. ${esc(x)}</span>`).join('')}</div>
      <form id="jcm814Create" class="jcm814-create">
        <label>Work case / machine<select id="jcm814Case" required><option value="">Loading cases...</option></select></label>
        <label>Technician<select id="jcm814Tech" required><option value="">Select case first...</option></select></label>
        <label>Job title<input id="jcm814Title" placeholder="Job title"></label>
        <label>Case type<input id="jcm814CaseType" value="Auto-detected after diagnosis" disabled></label>
        <label class="wide">Workshop Manager instruction<textarea id="jcm814Instruction" rows="2" placeholder="Scope, safety instruction, location note..."></textarea></label>
        <div class="jcm814-actions"><span id="jcm814Note" class="jcm814-note">Select a case and Technician. Existing active Job Card will be assigned/reassigned; otherwise a new Job Card is created.</span><button id="jcm814Assign" class="jcm814-button" type="submit">Create Job Card & Assign Technician</button></div>
      </form>
      <div class="jcm814-toolbar"><div><b>Job Cards</b><span id="jcm814Counts"></span></div><div class="jcm814-toolbar-actions"><input id="jcm814Search" type="search" aria-label="Search Job Cards" placeholder="Search job, machine, customer, technician"><button class="jcm814-filter active" type="button" data-jcm-filter="active">Active</button><a class="jcm814-filter" id="jcm814Completed" target="_top" href="/completed-maintenance-reports/">Completed Reports</a><button id="jcm814Refresh" class="jcm814-button green" type="button">Sync / Refresh</button></div></div>
      <div class="jcm814-table-wrap"><table class="jcm814-table"><thead><tr><th>Job Card / Machine</th><th>Technician</th><th>Case / Priority</th><th>Grounded</th><th>Process</th><th>Problem / Pending</th><th>Dates / Status</th><th>Manager Review</th><th>Report</th></tr></thead><tbody id="jcm814Rows"><tr><td colspan="9">Loading...</td></tr></tbody></table></div>`;
    grid.parentNode.insertBefore(root,grid);
    const oldTitle=doc.querySelector('.grid .panel .panel-head h2');if(oldTitle)oldTitle.textContent='Live Job Card / Breakdown Queue';
    const oldCopy=doc.querySelector('.grid .panel .panel-head p');if(oldCopy)oldCopy.textContent='Active machine issues remain here until Final Result = OK. Completed work is removed from the active queue but remains available in Job Card reports and process history.';
    const completedUrl=new URL('/completed-maintenance-reports/',location.origin);completedUrl.searchParams.set('actor',actor);completedUrl.searchParams.set('returnTo',location.pathname+location.search);doc.getElementById('jcm814Completed').href=completedUrl.pathname+completedUrl.search;doc.getElementById('jcm92Completed').href=completedUrl.pathname+completedUrl.search;
    root.querySelector('.jcm92-menu').addEventListener('click',event=>{const link=event.target.closest('[data-jc-page]');if(!link||event.ctrlKey||event.metaKey||event.shiftKey)return;event.preventDefault();navigateWorkspace(link.dataset.jcPage);});
    doc.getElementById('jcm92Detail').addEventListener('click',event=>{if(event.target.closest('[data-jc-back]'))navigateWorkspace('list');else rowAction(event);});
    root.querySelector('.jcm814-flow').addEventListener('click',event=>{if(event.target.closest('[data-jcm815-action="assign"]')){event.preventDefault();event.stopImmediatePropagation();navigateWorkspace('create');}},true);
    showWorkspace();
    doc.getElementById('jcm814Search').addEventListener('input',renderRows);
    doc.getElementById('jcm814Refresh').addEventListener('click',refresh);
    doc.getElementById('jcm814Case').addEventListener('change',caseChanged);
    doc.getElementById('jcm814Create').addEventListener('submit',assignJob);
    doc.getElementById('jcm814Rows').addEventListener('click',rowAction);
    root.querySelectorAll('[data-jcm-filter]').forEach(button=>button.addEventListener('click',()=>setListFilter(button.dataset.jcmFilter||'active')));
    refresh();
  }

  function note(message,type=''){const el=childDoc?.getElementById('jcm814Note');if(!el)return;el.textContent=message;el.className='jcm814-note'+(type?' '+type:'');const status=childDoc?.getElementById('jcm92Status');if(status){status.textContent=message;status.className=type;}}
  function caseLabel(c){const machine=[c.brand,c.model].filter(Boolean).join(' ')||val(c,'machineType','machine_type')||'Machine';const fleet=val(c,'fleetNumber','fleet_number');return `${machine}${fleet?` · Fleet ${fleet}`:''} · ${val(c,'title','description')||'Work case'}`}

  async function refresh(){
    if(busy)return;busy=true;const btn=childDoc?.getElementById('jcm814Refresh');if(btn)btn.disabled=true;
    try{
      const [processData,caseData]=await Promise.all([request('/api/job-card-workflow-v814?action=list&state=active'),workflowApi('')]);
      items=Array.from(new Map((Array.isArray(processData?.items)?processData.items:[]).map(item=>[String(item.id),item])).values());cases=(Array.isArray(caseData)?caseData:[]).filter(item=>!['COMPLETED','CANCELLED'].includes(up(item.status)));
      renderCases();renderRows();note(`Synced ${items.filter(x=>up(x.status)!=='CANCELLED'&&!hasFinalReport(x)).length} active Job Cards with no final report. Completed reports are available in the report archive.`,'ok');
    }catch(e){note(e.message||'Job Card sync failed.','error')}
    finally{busy=false;if(btn)btn.disabled=false}
  }

  function renderCases(){
    const select=childDoc?.getElementById('jcm814Case');if(!select)return;
    const current=select.value;
    select.innerHTML='<option value="">Select work case / machine...</option>'+cases.map(c=>`<option value="${esc(c.id)}">${esc(caseLabel(c))}</option>`).join('');
    if(cases.some(c=>String(c.id)===String(current)))select.value=current;
  }

  async function caseChanged(){
    const caseId=childDoc.getElementById('jcm814Case').value;const select=childDoc.getElementById('jcm814Tech');const title=childDoc.getElementById('jcm814Title');
    technicians=[];select.innerHTML='<option value="">Loading Technicians...</option>';if(!caseId){select.innerHTML='<option value="">Select case first...</option>';return}
    const c=cases.find(x=>String(x.id)===String(caseId));if(c&&!title.value.trim())title.value=val(c,'title','description')||'Machine repair';
    const customerId=val(c,'customerId','customer_id');
    try{
      technicians=await workflowApi(`/technicians?customerId=${encodeURIComponent(customerId)}`);technicians=Array.isArray(technicians)?technicians:[];
      select.innerHTML='<option value="">Select Technician...</option>'+technicians.map(t=>`<option value="${esc(t.id)}" data-temp="${t.temporaryForCustomer?'1':'0'}">${esc(t.name||t.email||'Technician')}${t.assignedCustomerName?` · Home: ${esc(t.assignedCustomerName)}`:''}${t.temporaryForCustomer?' · TEMP OVERRIDE':''}</option>`).join('');
    }catch(e){select.innerHTML='<option value="">Technician sync failed</option>';note(e.message,'error')}
  }

  async function assignJob(event){
    event.preventDefault();const caseId=childDoc.getElementById('jcm814Case').value;const techId=childDoc.getElementById('jcm814Tech').value;if(!caseId||!techId){note('Select Work Case and Technician.','error');return}
    const c=cases.find(x=>String(x.id)===String(caseId));const tech=technicians.find(x=>String(x.id)===String(techId));const title=childDoc.getElementById('jcm814Title').value.trim()||val(c,'title','description')||'Machine repair';const instruction=childDoc.getElementById('jcm814Instruction').value.trim();
    let override=false;if(tech?.temporaryForCustomer){override=childWin.confirm('This BELM Technician belongs to another home customer. Use Temporary Override for this Job Card only?');if(!override)return}
    const button=childDoc.getElementById('jcm814Assign');button.disabled=true;button.textContent='Assigning...';
    try{
      const result=await workflowApi('/job-card',{method:'POST',body:JSON.stringify({caseId,technicianId:techId,title,jobCardMode:'auto',temporaryOverride:override,workshopInstruction:instruction})});
      note(`Job Card ${result.jobCardNo||''} assigned to ${tech?.name||'Technician'}. Step 2 is Technician Receive.`,'ok');childDoc.getElementById('jcm814Instruction').value='';await refresh();navigateWorkspace('list');childDoc.getElementById('refreshButton')?.click();
    }catch(e){note(e.message,'error')}
    finally{button.disabled=false;button.textContent='Create Job Card & Assign Technician'}
  }

  function rowProcess(item){const step=Math.max(1,Math.min(8,Number(item.processStep||1)));return `<b>${esc(item.processLabel||processSteps[step-1])}</b><div class="jcm814-step-track">${processSteps.map((_,i)=>`<i class="${i+1<step?'done':i+1===step?'current':''}"></i>`).join('')}</div><small>Step ${step}/8 · ${esc(item.currentDepartment||'')}</small>`}
  function hasFinalReport(item){
    const status=up(item?.status);
    const final=up(item?.finalResult);
    const step=Number(item?.processStep||0);
    return status==='COMPLETED'||final==='OK'||step>=8||!!item?.completedAt;
  }
  function setListFilter(next){
    const safe=['active','completed','all'].includes(String(next||'').toLowerCase())?String(next).toLowerCase():'active';
    listFilter=safe;
    childDoc?.querySelectorAll('[data-jcm-filter]').forEach(button=>button.classList.toggle('active',button.dataset.jcmFilter===safe));
    renderRows();
  }

  function renderRows(){
    const body=childDoc?.getElementById('jcm814Rows');if(!body)return;
    const all=items.filter(x=>up(x.status)!=='CANCELLED');
    const activeCount=all.filter(x=>!hasFinalReport(x)).length;
    const completedCount=all.filter(hasFinalReport).length;
    const pendingCount=all.filter(x=>String(x.pendingReason||'').trim()&&!hasFinalReport(x)).length;
    const query=String(childDoc.getElementById('jcm814Search')?.value||'').trim().toLowerCase();
    const scoped=listFilter==='completed'?all.filter(hasFinalReport):listFilter==='all'?all:all.filter(x=>!hasFinalReport(x));
    const rows=scoped.filter(item=>!query||Object.values(item).filter(value=>typeof value==='string'||typeof value==='number').join(' ').toLowerCase().includes(query));
    const counts=childDoc.getElementById('jcm814Counts');
    if(counts)counts.textContent=` · ${activeCount} active · ${pendingCount} pending · Completed reports are available in the report archive`;
    childDoc?.querySelectorAll('[data-jcm-filter]').forEach(button=>button.classList.toggle('active',button.dataset.jcmFilter===listFilter));

    body.innerHTML=rows.length?rows.map(item=>{
      const status=up(item.status);
      const review=status==='REPORT_REVIEW';
      const final=up(item.finalResult);
      const pendingText=item.pendingReason||((review)?'Waiting Workshop Manager report review':(!item.receivedAt&&!hasFinalReport(item)?'Waiting technician to receive Job Card':'—'));
      const badgeClass=status==='COMPLETED'?'ok':review||pendingText!=='—'?'pending':final&&final!=='OK'?'red':'';
      const workCase=cases.find(c=>String(c.id)===String(item.caseId));
      const priority=val(item,'priority')||val(workCase,'priority','severity')||'Normal';
      const problem=item.faultDescription||item.title||'—';
      const created=fmtDateTime(item.createdAt||item.openedAt||item.startedAt);
      const updated=fmtDateTime(item.updatedAt);
      return `<tr data-job="${esc(item.id)}">
        <td><b>${esc(item.jobCardNo)}</b><small>${esc(item.machineLabel)} · Fleet ${esc(item.fleetNumber)}<br>${esc(item.customerName)}</small></td>
        <td><b>${esc(item.technicianName||'Unassigned')}</b><small>${esc(status.replaceAll('_',' '))}</small><small>${item.receivedAt?'Received: '+esc(fmtDateTime(item.receivedAt)):'Awaiting technician acknowledgement'}</small></td>
        <td><span class="jcm814-badge ${item.repeatIssue?'red':''}">${esc(item.caseType||'NEW CASE')}</span><small>Priority: ${esc(priority)}</small><small>${item.rootCause?`Root cause: ${esc(item.rootCause)}`:'Root cause pending diagnosis'}</small></td>
        <td><span class="jcm814-ground">${Number(item.groundedDays||0).toFixed(1)}</span><small>days grounded</small></td>
        <td>${rowProcess(item)}</td>
        <td class="jcm814-problem"><b>${esc(problem)}</b><small><span class="jcm814-badge ${badgeClass}">${esc(status==='COMPLETED'?'CLOSED':pendingText==='—'?'ON PROCESS':'PENDING')}</span></small><small>${esc(pendingText)}</small>${item.requiredSpare?`<small>Spare: ${esc(item.requiredSpare)}</small>`:''}</td>
        <td class="jcm814-dates"><small>Created</small><b>${esc(created)}</b><small>Updated: ${esc(updated)}</small><small><span class="jcm814-badge ${status==='COMPLETED'?'ok':review?'pending':''}">${esc(status.replaceAll('_',' '))}</span></small></td>
        <td>${review?`<div class="jcm814-row-actions"><button class="approve" data-review="approve">Approve Maintenance${item.requiredSpare?' + Spare':''}</button><button class="return" data-review="return">Return Report</button></div>`:`<span class="jcm814-badge ${item.maintenanceApproved?'ok':''}">${item.maintenanceApproved?'MAINTENANCE APPROVED':'—'}</span><small>${esc(item.managerReview||'')}</small>`}</td>
        <td><div class="jcm814-row-actions">${hasFinalReport(item)?'<button data-report>Report PDF</button>':'<span class="jcm814-badge pending">FINAL REPORT PENDING</span>'}<button data-view>View Details</button></div><small>Final: ${esc(item.finalResult||'Pending')}</small></td>
      </tr>`;
    }).join(''):'<tr><td colspan="9">No Job Cards in this filter.</td></tr>';
    if(workspacePage==='detail')renderDetail();
  }

  function showWorkspace(){
    if(!childDoc)return;
    const root=childDoc.getElementById('jobCardManagerV814');if(!root)return;
    root.dataset.page=workspacePage;
    root.querySelectorAll('[data-jc-page]').forEach(link=>{if(link.dataset.jcPage===workspacePage)link.setAttribute('aria-current','page');else link.removeAttribute('aria-current');});
    const detail=childDoc.getElementById('jcm92Detail');detail.hidden=workspacePage!=='detail';
    if(workspacePage==='detail')renderDetail();
  }
  function renderDetail(){
    const box=childDoc?.getElementById('jcm92Detail');if(!box)return;
    const item=items.find(row=>String(row.id)===selectedJob);
    if(!item){box.innerHTML='<button type="button" data-jc-back>← Active Job Cards</button><p>Job Card unavailable in the active queue. Check Completed Reports or refresh.</p>';return;}
    const fields=[['Machine',item.machineLabel],['Fleet',item.fleetNumber],['Customer',item.customerName],['Technician',item.technicianName],['Status',up(item.status).replaceAll('_',' ')],['Created',fmtDateTime(item.createdAt)],['Updated',fmtDateTime(item.updatedAt)],['Priority',item.priority],['Problem',item.faultDescription||item.title],['Diagnosis',item.diagnosis],['Explanation',item.explanation],['Findings',item.findings],['Root cause',item.rootCause],['Solution',item.solution],['Work done',item.workDone],['Required spare',item.requiredSpare],['Pending / follow-up',item.pendingReason],['Manager review',item.managerReview],['Test duration',String(item.testDurationMinutes||0)+' minutes'],['Final result',item.finalResult],['Grounded',String(item.groundedDays||0)+' days']];
    box.innerHTML=`<button type="button" data-jc-back>← Active Job Cards</button><article data-job="${esc(item.id)}"><h2>${esc(item.jobCardNo)} · ${esc(item.title||'Job Card')}</h2><p>${esc(item.processLabel||'Awaiting next action')}</p><dl class="jcm92-facts">${fields.map(([label,value])=>`<div><dt>${esc(label)}</dt><dd>${esc(value||'Not recorded')}</dd></div>`).join('')}</dl><div class="jcm814-row-actions">${up(item.status)==='REPORT_REVIEW'?'<button class="approve" data-review="approve">Approve Maintenance</button><button class="return" data-review="return">Return for Correction</button>':''}${hasFinalReport(item)?'<button data-report>Download Report PDF</button>':''}</div></article>`;
  }

  async function rowAction(event){
    const button=event.target.closest('button');if(!button)return;const row=button.closest('[data-job]');const id=row?.dataset.job;if(!id)return;const item=items.find(x=>String(x.id)===String(id));if(!item)return;
    if(button.hasAttribute('data-report')){await downloadReport(item);return}
    if(button.hasAttribute('data-view')){navigateWorkspace('detail',item.id);return}
    const type=button.dataset.review;if(!type)return;
    const approve=type==='approve';let noteText='';
    if(approve){noteText=childWin.prompt(`Review note for ${item.jobCardNo} (optional):`,'')||'';if(!childWin.confirm(`Approve Technician Report and maintenance${item.requiredSpare?' / required spare':''}?`))return}
    else{noteText=childWin.prompt('Reason / correction required from Technician:','')||'';if(!noteText.trim())return}
    button.disabled=true;
    try{const result=await processApi('review-report',{id,fetch:{method:'PUT',body:JSON.stringify({approve,note:noteText.trim()})}});note(result.message||'Review updated.','ok');await refresh();childDoc.getElementById('refreshButton')?.click()}
    catch(e){note(e.message,'error')}
    finally{button.disabled=false}
  }

  async function downloadReport(item){
    try{
      const r=await fetch(`/api/job-card-workflow-v814?action=report&id=${encodeURIComponent(item.id)}`,{cache:'no-store',headers:{Authorization:`Bearer ${token}`}});if(!r.ok){const t=await r.text();let d={};try{d=JSON.parse(t)}catch{}throw new Error(d.error||'Could not generate Job Card report.')}
      const blob=await r.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`${item.jobCardNo||'Job-Card'}-FINAL-REPORT.pdf`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
    }catch(e){note(e.message,'error')}
  }

  if(frame)frame.addEventListener('load',()=>setTimeout(mount,80));
  else if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
})();