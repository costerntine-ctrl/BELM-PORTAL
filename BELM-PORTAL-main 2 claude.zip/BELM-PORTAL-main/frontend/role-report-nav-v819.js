(function(){
  'use strict';
  if(window.__belmRoleReportNav819)return;
  window.__belmRoleReportNav819=true;

  function token(){
    const active=String(localStorage.getItem('belm_active_account_type')||'').toLowerCase();
    const preferred={customer:'belm_customer_token',technician:'belm_tech_token',admin:'belm_admin_token',operator:'belm_operator_token'}[active]||'';
    return [preferred,'belm_admin_token','belm_tech_token','belm_customer_token','belm_operator_token']
      .filter((v,i,a)=>v&&a.indexOf(v)===i).map(k=>localStorage.getItem(k)||'').find(Boolean)||'';
  }
  function decode(v){try{let r=(v.split('.')[1]||'').replace(/-/g,'+').replace(/_/g,'/');r+='='.repeat((4-r.length%4)%4);return JSON.parse(decodeURIComponent(Array.from(atob(r)).map(c=>'%'+c.charCodeAt(0).toString(16).padStart(2,'0')).join('')))}catch(_){return{}}}
  const s=decode(token());if(!Object.keys(s).length)return;
  const customerAliases={owner:'customer_admin',admin:'customer_admin',customer_admin:'customer_admin',workshop_manager:'workshop_manager',technician:'technician',operator:'operator',procurement:'procurement',store_keeper:'store_keeper',accounts:'accounts',finance:'accounts',accountant:'accounts'};
  const staffAliases={'Super Admin':'super_admin','Workshop Manager':'workshop_manager','Engineer':'workshop_manager','Technician':'technician','Procurement':'procurement','Store Keeper':'store_keeper','Registration & Sales':'registration_sales','Finance / Accounts':'finance_accounts','Bank Controller':'bank_controller','System Coordinator':'system_coordinator','Operator':'operator','Machine Operator':'operator'};
  const managedTech=s.type==='staff'&&!!s.isCustomerManaged&&!!s.assignedCustomerId;
  const isCustomer=s.type==='customer'||s.type==='operator'||managedTech;
  const role=isCustomer?(s.type==='operator'?'operator':managedTech?'technician':customerAliases[String(s.customerRole||(s.actorType==='owner'?'owner':'')).toLowerCase()]||'unknown'):(Object.entries(staffAliases).find(([name])=>name.toLowerCase()===String(s.roleName||'').trim().toLowerCase())?.[1]||'unknown');
  const isAdmin=role==='super_admin'||role==='customer_admin';
  const path=(location.pathname.replace(/\/+$/,'')||'/');
  if(path==='/role-reports'||path==='/role-analysis')return;

  const icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="3" width="14" height="18" rx="1.5"/><path d="M9 8h6M9 12h6M9 16h4"/></svg>';
  const reportText=/^(my reports|operator reports|purchase reports|inventory reports|customer reports|reports|role reports)$/i;
  const legacyHref=/(?:^|\/)(?:my-reports|purchase-reports|inventory-reports|customer-reports|operator-reports|reports)\.(?:php|html)(?:$|[?#])/i;
  const adminHome=(role==='super_admin'&&path==='/concept-dashboards/01-admin-home')||(role==='customer_admin'&&path==='/customer-admin-dashboard');

  // V835: every DOM write is conditional. Unconditional textContent/attribute
  // writes re-triggered this script's own MutationObserver (and other role
  // scripts' observers) every frame, which snowballed until Chrome reported the
  // page unresponsive - e.g. Customer Roles & Users froze while editing logins.
  // V836: role-correct General Report destinations.
  function generalReportHref(){
    return isCustomer?'/general-report/':'/reports-manager/?module=reports';
  }
  function setAttr(el,name,value){if(el.getAttribute(name)!==value)el.setAttribute(name,value)}
  function setData(el,key,value){if(el.dataset[key]!==value)el.dataset[key]=value}
  function labelAnchor(a,label){
    const span=a.querySelector(':scope>span');
    if(span){if(span.textContent!==label)span.textContent=label;}
    else{
      const texts=Array.from(a.childNodes).filter(n=>n.nodeType===Node.TEXT_NODE);
      const target=texts.find(n=>String(n.nodeValue||'').trim());
      if(target){if(String(target.nodeValue).trim()!==label)target.nodeValue=' '+label;}
      else a.insertAdjacentText('beforeend',' '+label);
    }
  }

  const busyNavs=new WeakSet();
  function normalizeNav(nav){
    if(!nav||busyNavs.has(nav))return;
    busyNavs.add(nav);
    try{
      if(isAdmin){
        const links=Array.from(nav.querySelectorAll('a[href]')).filter(a=>/\/(role-reports|role-analysis|general-report|general-analysis|reports-manager)(?:[/.?]|$)/i.test(a.getAttribute('href')||'')||/^(my (role )?reports?|my analysis|general reports?|general analysis|reports|analysis)$/i.test(String(a.textContent||'').trim()));
        let general=links.shift();links.forEach(a=>a.remove());
        if(!general){general=document.createElement('a');general.className=nav.querySelector('a')?.className||'belm-nav__item';general.innerHTML=icon+'<span>General Report</span>';nav.appendChild(general);}
        setAttr(general,'href','/reports-manager/?module=reports');labelAnchor(general,'General Report');setData(general,'reportScope','general-admin');
        return;
      }
      let my=null;
      Array.from(nav.querySelectorAll(':scope a[href],a[href]')).forEach(a=>{
        const text=String(a.textContent||'').replace(/\s+/g,' ').trim();
        const href=String(a.getAttribute('href')||'');
        if(/reports[-_]analysis|department-analysis|general-analysis\.php|^\/general-analysis\//i.test(href)||/^reports?\s*&\s*analysis$/i.test(text)){
          setAttr(a,'href','/role-analysis/');labelAnchor(a,'My Analysis');setData(a,'analysisScope','role');return;
        }
        const isGeneral=/general-report/i.test(href)||/^general report$/i.test(text);
        if(isGeneral){
          if(isAdmin&&adminHome){
            // V836: BELM Super Admin's General Report is the consolidated BELM
            // report centre. /general-report/ is the CUSTOMER machine-report
            // page; it has no BELM session, so it sent Super Admin to /login.
            setAttr(a,'href',generalReportHref());
            labelAnchor(a,'General Report');
            setData(a,'reportScope','general-admin');
          }else{
            setAttr(a,'href','/role-reports/');
            labelAnchor(a,'My Reports');
            setData(a,'reportScope','role');
            my=my||a;
          }
          return;
        }
        if(reportText.test(text)||legacyHref.test(href)){
          setAttr(a,'href','/role-reports/');
          labelAnchor(a,'My Reports');
          setData(a,'reportScope','role');
          my=my||a;
        }
      });

      let analysisLinks=Array.from(nav.querySelectorAll('a[href]')).filter(a=>a.getAttribute('href')==='/role-analysis/');
      if(!analysisLinks.length){const a=document.createElement('a');a.href='/role-analysis/';a.dataset.analysisScope='role';const sample=nav.querySelector('a');a.className=sample?.classList.contains('nav-item')?'nav-item':'belm-nav__item';a.innerHTML=icon+'<span>My Analysis</span>';nav.appendChild(a);}
      else analysisLinks.slice(1).forEach(a=>a.remove());
      if(!my){
        const a=document.createElement('a');
        a.href='/role-reports/';
        a.dataset.reportScope='role';
        const sample=nav.querySelector('a');
        a.className=sample?.classList.contains('nav-item')?'nav-item':'belm-nav__item';
        a.innerHTML=icon+'<span>My Reports</span>';
        const settings=Array.from(nav.querySelectorAll('a')).find(x=>/settings|profile/i.test(String(x.textContent||'')));
        if(settings)nav.insertBefore(a,settings);else nav.appendChild(a);
        my=a;
      }

      Array.from(nav.querySelectorAll('a[href]')).forEach(a=>{
        const text=String(a.textContent||'').replace(/\s+/g,' ').trim();
        const href=String(a.getAttribute('href')||'');
        if(/^my profile$/i.test(text)||/(?:^|\/)my-profile\.(?:php|html)(?:$|[?#])/i.test(href)){
          setAttr(a,'href','/my-profile/');
          labelAnchor(a,'My Profile');
          setData(a,'profileScope','registration');
        }
      });

      // Keep one My Reports and one My Profile only. Some older role pages
      // already contain these links while shared navigation also injects them.
      const reportLinks=Array.from(nav.querySelectorAll('a[href]')).filter(a=>{
        const text=String(a.textContent||'').replace(/\s+/g,' ').trim();
        const href=String(a.getAttribute('href')||'');
        return a.dataset.reportScope==='role'||/my reports/i.test(text)||/\/role-reports\/?(?:$|[?#])/.test(href);
      });
      reportLinks.slice(1).forEach(a=>a.remove());
      // V836: keep one General Report link (dashboard + shared nav could both add one).
      Array.from(nav.querySelectorAll('a[href]')).filter(a=>a.dataset.reportScope==='general-admin').slice(1).forEach(a=>a.remove());

      if(role==='technician'&&!isCustomer){
        Array.from(nav.querySelectorAll('a[href]')).forEach(a=>{
          const text=String(a.textContent||'').replace(/\s+/g,' ').trim();
          const href=String(a.getAttribute('href')||'');
          if(/diagnosis report|diagnosis\s*&\s*repair/i.test(text)||/diagnosis-repair\.php/i.test(href))a.remove();
        });
      }

      let profile=Array.from(nav.querySelectorAll('a[href]')).find(a=>/^my profile$/i.test(String(a.textContent||'').replace(/\s+/g,' ').trim()));
      if(!profile){
        profile=document.createElement('a');
        profile.href='/my-profile/';
        profile.dataset.profileScope='registration';
        const sample=nav.querySelector('a');
        profile.className=sample?.classList.contains('nav-item')?'nav-item':'belm-nav__item';
        profile.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="3.2"/><path d="M5 20c0-3.9 3.1-6.5 7-6.5s7 2.6 7 6.5"/></svg><span>My Profile</span>';
        const settings=Array.from(nav.querySelectorAll('a')).find(x=>/settings/i.test(String(x.textContent||'')));
        if(settings)nav.insertBefore(profile,settings);else nav.appendChild(profile);
      }

      const profileLinks=Array.from(nav.querySelectorAll('a[href]')).filter(a=>{
        const text=String(a.textContent||'').replace(/\s+/g,' ').trim();
        const href=String(a.getAttribute('href')||'');
        return a.dataset.profileScope==='registration'||/my profile/i.test(text)||/\/my-profile\/?(?:$|[?#])/.test(href);
      });
      profileLinks.slice(1).forEach(a=>a.remove());

      if(isAdmin&&adminHome&&!Array.from(nav.querySelectorAll('a')).some(a=>a.dataset.reportScope==='general-admin'||/^general report$/i.test(String(a.textContent||'').trim()))){
        const a=document.createElement('a');
        a.href=generalReportHref();
        a.dataset.reportScope='general-admin';
        const sample=nav.querySelector('a');
        a.className=sample?.classList.contains('nav-item')?'nav-item':'belm-nav__item';
        a.innerHTML=icon+'<span>General Report</span>';
        const settings=Array.from(nav.querySelectorAll('a')).find(x=>/settings/i.test(String(x.textContent||'')));
        if(settings)nav.insertBefore(a,settings);else nav.appendChild(a);
      }
    }finally{busyNavs.delete(nav)}
  }

  function coordinatorCard(){
    if(role!=='system_coordinator')return;
    const grid=document.querySelector('.settings-card-grid');
    if(!grid||grid.querySelector('[data-role-my-reports]'))return;
    const a=document.createElement('a');
    a.className='settings-card blue';
    a.href='/role-reports/';
    a.dataset.roleMyReports='1';
    a.innerHTML='<span class="settings-card-icon">▤</span><h2>My Reports</h2><p>System access, user activity, configuration and audit reports for System Coordinator.</p><span class="settings-card-button">Open My Reports</span>';
    grid.appendChild(a);
  }

  function scan(){
    document.querySelectorAll('.belm-nav,.sidebar-nav,.sidebar nav,.belm-admin-sidebar nav,.portal-nav').forEach(normalizeNav);
    coordinatorCard();
  }
  // V835: coalesce observer bursts into at most one scan per frame.
  let scanQueued=false;
  function queueScan(){if(scanQueued)return;scanQueued=true;requestAnimationFrame(()=>{scanQueued=false;scan()})}
  function boot(){scan();new MutationObserver(queueScan).observe(document.body,{childList:true,subtree:true});[300,900,1800,3200].forEach(ms=>setTimeout(scan,ms))}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();